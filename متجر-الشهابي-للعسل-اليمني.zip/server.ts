import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  const dataPath = path.join(__dirname, "src", "data", "products.json");

  // API to get products
  app.get("/api/products", (req, res) => {
    try {
      const data = fs.readFileSync(dataPath, "utf8");
      res.json(JSON.parse(data));
    } catch (error) {
      res.status(500).json({ error: "Failed to read products" });
    }
  });

  // API to update products (Admin)
  app.post("/api/products", (req, res) => {
    const { password, products } = req.body;
    if (password !== process.env.ADMIN_PASSWORD && password !== "774586524") {
      return res.status(401).json({ error: "Unauthorized" });
    }

    try {
      fs.writeFileSync(dataPath, JSON.stringify(products, null, 2));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to save products" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
