import fs from 'fs';
const content = fs.readFileSync('src/App.tsx', 'utf8');
const nonAscii = content.match(/[^\x00-\x7f\u0600-\u06ff\u0750-\u077f\ufb50-\ufdff\ufe70-\ufeff]/g);
if (nonAscii) {
  console.log('Found non-ASCII/non-Arabic characters:', nonAscii.join(''));
} else {
  console.log('No non-ASCII/non-Arabic characters found.');
}
