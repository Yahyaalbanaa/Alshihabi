import * as React from "react";
import { useState, useEffect, FormEvent, useRef, Component } from "react";
import { motion, AnimatePresence } from "motion/react";
import * as htmlToImage from "html-to-image";
import imageCompression from 'browser-image-compression';
import { 
  ShoppingBag, 
  Heart, 
  Home, 
  Menu, 
  Headset, 
  Sun,
  Moon,
  X, 
  Plus, 
  Minus, 
  Trash2, 
  CheckCircle2, 
  Send,
  Instagram,
  Facebook,
  Phone,
  Settings,
  ArrowLeft,
  Share2,
  Download,
  ChevronLeft,
  ChevronRight,
  Star,
  ExternalLink,
  Search,
  MapPin,
  Mic,
  History,
  RotateCcw,
  User,
  UserPlus,
  Image,
  Mail,
  Lock,
  Upload
} from "lucide-react";

// --- Custom Components ---
import { WhatsAppIcon } from "./components/WhatsAppIcon";
import { HomeSlider } from "./components/HomeSlider";
import { ProductCard } from "./components/ProductCard";
import { SidebarItem } from "./components/SidebarItem";
import { DeveloperCard } from "./components/DeveloperCard";
import { StoreOwnerCard } from "./components/StoreOwnerCard";
import { Carousel } from "./components/Carousel";
import { Badge } from "./components/Badge";
import { NavItem } from "./components/NavItem";
import { Logo } from "./components/Assets";

// --- Data ---
import initialProducts from "./data/products.json";
import initialSlides from "./data/slides.json";

// --- Types ---
import { Product, HomeSlide, CartItem, OrderDetails, CurrencyCode, CurrencyOption, Order } from "./types";

const CURRENCIES: CurrencyOption[] = [
  { code: "OLD_YER", label: "ريال يمني قديم", symbol: "ر.ي.ق", rate: 1 },
  { code: "NEW_YER", label: "ريال يمني جديد", symbol: "ر.ي.ج", rate: 1560 / 530 },
  { code: "SAR", label: "ريال سعودي", symbol: "ر.س", rate: 1 / 140 },
  { code: "USD", label: "دولار", symbol: "$", rate: 1 / 530 }
];

const sanitizeForFirestore = (obj: any): any => {
  if (Array.isArray(obj)) {
    return obj.map(v => sanitizeForFirestore(v));
  } else if (obj !== null && typeof obj === 'object') {
    return Object.fromEntries(
      Object.entries(obj)
        .filter(([_, v]) => v !== undefined)
        .map(([k, v]) => [k, sanitizeForFirestore(v)])
    );
  }
  return obj;
};

// --- Firebase ---
import { 
  db, 
  auth, 
  collection, 
  doc, 
  getDoc,
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  where,
  getDocs,
  orderBy, 
  handleFirestoreError, 
  OperationType
} from "./firebase";
import type { User as FirebaseUser } from "./firebase";

// --- Components ---

// --- Error Boundary ---
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends (Component as any) {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("ErrorBoundary caught an error", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      let errorMessage = "حدث خطأ غير متوقع. يرجى إعادة تحميل الصفحة.";
      try {
        const parsed = JSON.parse(this.state.error.message);
        if (parsed.error) errorMessage = `خطأ في قاعدة البيانات: ${parsed.error}`;
      } catch (e) {
        // Not a JSON error
      }

      return (
        <div className="min-h-screen bg-background flex items-center justify-center p-6 text-center">
          <div className="bg-surface-container-high p-8 rounded-[40px] border border-white/10 max-w-md w-full space-y-6">
            <div className="w-20 h-20 bg-error/10 text-error rounded-full flex items-center justify-center mx-auto">
              <X size={40} />
            </div>
            <h2 className="text-2xl font-bold">عذراً، حدث خطأ</h2>
            <p className="text-on-surface-variant text-sm">{errorMessage}</p>
            <button 
              onClick={() => window.location.reload()} 
              className="w-full py-4 bg-primary text-on-primary rounded-full font-bold shadow-xl shadow-primary/20"
            >
              إعادة تحميل الصفحة
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// --- Tracking Timeline Component ---
function TrackingTimeline({ status }: { status: Order["status"] }) {
  const steps: { key: Order["status"]; label: string }[] = [
    { key: "received", label: "تم الاستلام" },
    { key: "processing", label: "جاري التجهيز" },
    { key: "shipped", label: "تم الشحن" },
    { key: "delivered", label: "تم التسليم" },
  ];

  const getStatusIndex = (s: string) => steps.findIndex(step => step.key === s);
  const currentIndex = getStatusIndex(status);

  if (status === "rejected") {
    return (
      <div className="bg-error/10 text-error p-3 rounded-xl text-xs font-bold flex items-center gap-2">
        <X size={16} /> تم رفض الطلب
      </div>
    );
  }

  return (
    <div className="relative flex justify-between items-center py-4 px-2">
      <div className="absolute left-8 right-8 h-0.5 bg-white/10 top-1/2 -translate-y-1/2 z-0" />
      <div 
        className="absolute right-8 h-0.5 bg-primary top-1/2 -translate-y-1/2 z-0 transition-all duration-1000 origin-right" 
        style={{ width: `${currentIndex >= 0 ? (currentIndex / (steps.length - 1)) * 100 : 0}%`, maxWidth: 'calc(100% - 64px)' }} 
      />
      
      {steps.map((step, index) => {
        const isActive = index <= currentIndex;
        const isCurrent = index === currentIndex;
        
        return (
          <div key={step.key} className="relative z-10 flex flex-col items-center gap-2">
            <div className={`w-3 h-3 rounded-full transition-all duration-500 ${isActive ? "bg-primary shadow-[0_0_10px_rgba(var(--primary-rgb),0.5)] scale-125" : "bg-surface-container-high border border-white/10"}`}>
              {isCurrent && <div className="w-full h-full rounded-full bg-primary animate-ping" />}
            </div>
            <span className={`text-[8px] font-bold transition-colors duration-500 whitespace-nowrap ${isActive ? "text-primary" : "text-on-surface-variant"}`}>
              {step.label}
            </span>
          </div>
        );
      })}
    </div>
  );
}

// --- Orders View for Customers ---
function OrdersView({ formatPrice, addToCart, currentUser, setView, showMessage }: { formatPrice: (p: number) => string, addToCart: any, currentUser: any, setView: any, showMessage: any }) {
  const [phone, setPhone] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [customerOrders, setCustomerOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const user = auth.currentUser;
    if ((isLoggedIn || currentUser || user) && (currentUser || user || phone)) {
      setLoading(true);
      
      const activeUser = currentUser || user;
      let q;
      
      // If we have a phone, we prefer querying by phone to find all orders (even those placed before login)
      if (phone) {
        q = query(collection(db, "orders"), where("details.phone", "==", phone), orderBy("date", "desc"));
      } else if (activeUser) {
        q = query(collection(db, "orders"), where("userId", "==", activeUser.uid), orderBy("date", "desc"));
      } else {
        setLoading(false);
        return;
      }
      
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const filtered = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }) as Order);
        setCustomerOrders(filtered);
        setLoading(false);
      }, (error) => {
        console.error("OrdersView Error:", error);
        // If phone query fails, try userId query if we have it
        if (activeUser && phone) {
           const userQ = query(collection(db, "orders"), where("userId", "==", activeUser.uid), orderBy("date", "desc"));
           onSnapshot(userQ, (snap) => {
             setCustomerOrders(snap.docs.map(d => ({ id: d.id, ...d.data() }) as Order));
             setLoading(false);
           }, (err2) => {
             console.error("User Query Error:", err2);
             setLoading(false);
           });
        } else {
          setLoading(false);
        }
      });
      
      return () => unsubscribe();
    }
  }, [isLoggedIn, phone, currentUser]);

  const handleGoogleLogin = async () => {
    try {
      const { googleProvider, signInWithPopup } = await import("./firebase");
      await signInWithPopup(auth, googleProvider);
      showMessage("تم تسجيل الدخول بنجاح", "success");
    } catch (error) {
      showMessage("فشل تسجيل الدخول", "error");
    }
  };

  const handlePhoneLogin = async () => {
    if (phone.length < 9) {
      showMessage("يرجى إدخال رقم هاتف صحيح", "error");
      return;
    }
    
    setLoading(true);
    try {
      const { signInAnonymously } = await import("firebase/auth");
      let user = auth.currentUser;
      if (!user) {
        const userCredential = await signInAnonymously(auth);
        user = userCredential.user;
      }

      const mappingSnap = await getDoc(doc(db, "phone_to_uid", phone));
      if (!mappingSnap.exists()) {
        // Create mapping and user doc
        await setDoc(doc(db, "phone_to_uid", phone), { uid: user.uid });
        await setDoc(doc(db, "users", user.uid), { phone, name: "عميل الشهابي", createdAt: new Date().toISOString() }, { merge: true });
        showMessage("تم إنشاء حسابك بنجاح", "success");
      } else {
        // Link current UID to this phone
        await setDoc(doc(db, "users", user.uid), { phone }, { merge: true });
        showMessage(`مرحباً بك مجدداً`, "success");
      }
      setIsLoggedIn(true);
    } catch (err) {
      console.error("Login error:", err);
      showMessage("فشل تسجيل الدخول، يرجى المحاولة لاحقاً", "error");
    } finally {
      setLoading(false);
    }
  };

  const reOrder = (items: CartItem[]) => {
    items.forEach(item => addToCart(item));
    showMessage("تم إضافة المنتجات للسلة", "success");
    setView("cart");
  };

  if (!isLoggedIn && !currentUser) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-md mx-auto py-12 px-6 space-y-8 text-center">
        <div className="flex justify-start">
          <button onClick={() => setView("home")} className="flex items-center gap-2 text-primary font-bold text-xs bg-primary/10 px-4 py-2 rounded-xl">
            <ChevronRight size={16} /> العودة
          </button>
        </div>
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <History size={40} className="text-primary" />
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold">طلباتي السابقة</h2>
          <p className="text-on-surface-variant text-sm">سجل دخولك لمتابعة طلباتك وحفظ مكافآتك</p>
        </div>
        
        <div className="space-y-4">
          <button 
            onClick={handleGoogleLogin}
            className="w-full py-4 bg-white text-black border border-gray-200 rounded-full font-bold flex items-center justify-center gap-3 shadow-lg hover:bg-gray-50 transition-all active:scale-95"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-6 h-6" alt="" />
            الدخول عبر جوجل
          </button>

          <div className="relative py-4">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
            <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-2 text-on-surface-variant">أو إنشاء حساب بالهاتف</span></div>
          </div>

          <div className="space-y-4">
            <input 
              type="tel" 
              placeholder="رقم الهاتف (مثال: 774586524)" 
              className="w-full bg-surface-container-low border border-white/5 rounded-2xl p-4 text-center focus:border-primary/50 transition-all outline-none"
              value={phone}
              onChange={e => setPhone(e.target.value)}
            />
            <button 
              onClick={handlePhoneLogin}
              className="w-full py-4 bg-primary text-on-primary rounded-full font-bold shadow-xl shadow-primary/20 hover:brightness-110 active:scale-95 transition-all"
            >
              دخول / إنشاء حساب
            </button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6 pb-20">
      <div className="flex items-center justify-between pt-4">
        <button onClick={() => setView("home")} className="flex items-center gap-2 text-primary font-bold text-xs bg-primary/10 px-4 py-2 rounded-xl hover:bg-primary/20 transition-all">
          <ChevronRight size={16} /> العودة
        </button>
        <h2 className="text-2xl font-bold">سجل طلباتي</h2>
        <div className="flex gap-2">
          {currentUser ? (
            <div className="flex items-center gap-2 bg-primary/10 px-3 py-1 rounded-full border border-primary/20">
              <img 
                src={currentUser.photoURL || ""} 
                className="w-5 h-5 rounded-full" 
                alt={currentUser.displayName || "User"} 
                referrerPolicy="no-referrer"
              />
              <span className="text-[10px] font-bold text-primary">{currentUser.displayName}</span>
            </div>
          ) : (
            <button onClick={() => { setIsLoggedIn(false); setCustomerOrders([]); }} className="text-primary text-sm font-bold">تغيير الرقم</button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="py-20 text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="mt-4 text-on-surface-variant">جاري تحميل طلباتك...</p>
        </div>
      ) : customerOrders.length === 0 ? (
        <div className="py-20 text-center space-y-4">
          <div className="w-16 h-16 bg-surface-container-high rounded-full flex items-center justify-center mx-auto opacity-50">
            <ShoppingBag size={30} />
          </div>
          <p className="text-on-surface-variant">لا توجد طلبات سابقة</p>
          {currentUser && <p className="text-[10px] text-on-surface-variant">لم تقم بأي طلبات باستخدام هذا الحساب بعد</p>}
        </div>
      ) : (
        <div className="space-y-6">
          {customerOrders.map(order => (
            <div key={order.id} className="bg-surface-container-low rounded-[40px] p-6 border border-white/5 space-y-6 shadow-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[10px] text-on-surface-variant mb-1 font-bold">{new Date(order.date).toLocaleDateString("ar-YE", { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                  <h3 className="font-bold text-lg">طلب <span className="text-primary">#{order.id.slice(-6)}</span></h3>
                </div>
                <Badge 
                  label={
                    order.status === "received" ? "تم الاستلام" : 
                    order.status === "processing" ? "قيد التجهيز" : 
                    order.status === "shipped" ? "تم الشحن" : 
                    order.status === "delivered" ? "تم التسليم" : "مرفوض"
                  } 
                  variant={
                    order.status === "delivered" ? "success" : 
                    order.status === "rejected" ? "danger" : "warning"
                  } 
                />
              </div>

              <TrackingTimeline status={order.status} />

              <div className="bg-background/50 rounded-3xl p-4 space-y-3">
                {order.items.map((item, i) => (
                  <div key={i} className="flex justify-between items-center text-sm">
                    <div className="flex items-center gap-3">
                      <img 
                        src={item.image} 
                        className="w-10 h-10 rounded-lg object-cover" 
                        alt={item.name} 
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <p className="font-bold">{item.name}</p>
                        <p className="text-[10px] text-on-surface-variant">{item.selectedSize || "حجم قياسي"} x{item.quantity}</p>
                      </div>
                    </div>
                    <span className="font-bold text-primary">{formatPrice(item.finalPrice * item.quantity)} {order.currency.symbol}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                <div>
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">الإجمالي</p>
                  <p className="text-xl font-bold text-primary">{formatPrice(order.total)} {order.currency.symbol}</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => reOrder(order.items)}
                    className="flex items-center gap-2 bg-white/5 text-on-surface px-4 py-3 rounded-2xl text-xs font-bold hover:bg-white/10 transition-all border border-white/10"
                  >
                    <RotateCcw size={16} />
                    إعادة طلب
                  </button>
                  <button 
                    onClick={() => {
                      const text = `استفسار عن الطلب #${order.id}\nالحالة: ${order.status}`;
                      window.open(`https://wa.me/967774586524?text=${encodeURIComponent(text)}`, "_blank");
                    }}
                    className="p-3 bg-primary text-on-primary rounded-2xl shadow-lg shadow-primary/20 hover:scale-105 transition-all"
                  >
                    <WhatsAppIcon size={20} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}

// --- Admin Orders Manager ---
function AdminOrdersManager({ orders, formatPrice, showMessage }: { orders: Order[], formatPrice: (p: number) => string, showMessage: any }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  const updateStatus = async (id: string, status: Order["status"]) => {
    try {
      await updateDoc(doc(db, "orders", id), { status });
      showMessage("تم تحديث حالة الطلب بنجاح", "success");
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `orders/${id}`);
    }
  };

  const deleteOrder = async (id: string) => {
    try {
      await deleteDoc(doc(db, "orders", id));
      setShowDeleteConfirm(null);
      showMessage("تم حذف الطلب بنجاح", "success");
    } catch (error) {
      console.error("Delete Order Error:", error);
      handleFirestoreError(error, OperationType.DELETE, `orders/${id}`);
    }
  };

  const filteredOrders = orders.filter(order => {
    const search = searchTerm.toLowerCase().replace(/\s/g, "");
    const orderId = order.id.toLowerCase();
    const phone = (order.details.phone || "").replace(/\D/g, "");
    const name = (order.details.name || "").toLowerCase();
    
    const matchesSearch = orderId.includes(search) || 
                         phone.includes(search) || 
                         name.includes(search);
    
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "completed" && order.status === "delivered") ||
                         (statusFilter === "processing" && (order.status === "received" || order.status === "processing" || order.status === "shipped")) ||
                         (statusFilter === "rejected" && order.status === "rejected");

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h2 className="text-2xl font-bold">إدارة الطلبات ({filteredOrders.length})</h2>
        <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
          <div className="flex gap-2 bg-surface-container-low p-1 rounded-2xl border border-white/5">
            <button onClick={() => setStatusFilter("all")} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${statusFilter === "all" ? "bg-primary text-on-primary" : "text-on-surface-variant hover:bg-white/5"}`}>الكل</button>
            <button onClick={() => setStatusFilter("processing")} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${statusFilter === "processing" ? "bg-amber-500 text-white" : "text-on-surface-variant hover:bg-white/5"}`}>قيد التنفيذ</button>
            <button onClick={() => setStatusFilter("completed")} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${statusFilter === "completed" ? "bg-green-600 text-white" : "text-on-surface-variant hover:bg-white/5"}`}>مكتمل</button>
            <button onClick={() => setStatusFilter("rejected")} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${statusFilter === "rejected" ? "bg-error text-on-error" : "text-on-surface-variant hover:bg-white/5"}`}>مرفوض</button>
          </div>
          <div className="relative w-full md:w-64">
            <input 
              type="text" 
              placeholder="بحث..." 
              className="w-full bg-surface-container-low border border-white/10 rounded-2xl py-3 px-10 outline-none focus:border-primary/50 text-sm"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-primary" size={16} />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {filteredOrders.map(order => (
          <div key={order.id} className="bg-surface-container-low rounded-[32px] p-6 border border-white/5 space-y-6 shadow-lg hover:border-primary/20 transition-all">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-lg">طلب <span className="text-primary">#{order.id}</span></h3>
                  <Badge 
                    label={
                      order.status === "received" ? "تم الاستلام" : 
                      order.status === "processing" ? "قيد التجهيز" : 
                      order.status === "shipped" ? "تم الشحن" : 
                      order.status === "delivered" ? "مكتمل" : "مرفوض"
                    } 
                    variant={
                      order.status === "delivered" ? "success" : 
                      order.status === "rejected" ? "danger" : "warning"
                    } 
                  />
                  {(order as any).isLoyaltyOrder && (
                    <Badge label="طلب نقاط النحل" variant="warning" />
                  )}
                </div>
                <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-wider">بتاريخ: {new Date(order.date).toLocaleString("ar-YE")}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                    <Phone size={14} />
                  </div>
                  <p className="text-sm font-black">{order.details.phone}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <select 
                  className="bg-background border border-white/10 rounded-xl p-2 text-xs font-bold outline-none focus:border-primary"
                  value={order.status}
                  onChange={(e) => updateStatus(order.id, e.target.value as any)}
                >
                  <option value="received">تم الاستلام</option>
                  <option value="processing">جاري التجهيز</option>
                  <option value="shipped">تم الشحن</option>
                  <option value="delivered">مكتمل</option>
                  <option value="rejected">مرفوض</option>
                </select>
                <button onClick={() => setShowDeleteConfirm(order.id)} className="text-error/60 hover:text-error p-2 hover:bg-error/10 rounded-xl transition-all"><Trash2 size={20} /></button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-primary flex items-center gap-2">
                  <ShoppingBag size={16} /> المنتجات
                </h4>
                <div className="space-y-2 bg-black/20 p-4 rounded-2xl border border-white/5">
                  {order.items.map((item, i) => (
                    <div key={i} className="flex justify-between text-sm">
                      <span className="font-medium">{item.name} {item.selectedSize ? `(${item.selectedSize})` : ""} x{item.quantity}</span>
                      <span className="font-bold text-primary">{formatPrice(item.finalPrice * item.quantity)} {order.currency.symbol}</span>
                    </div>
                  ))}
                  <div className="pt-2 mt-2 border-t border-white/10 flex justify-between font-black text-lg">
                    <span>الإجمالي</span>
                    <span className="text-primary">{formatPrice(order.total)} {order.currency.symbol}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-bold text-sm text-primary flex items-center gap-2">
                  <MapPin size={16} /> تفاصيل التوصيل
                </h4>
                <div className="space-y-2 text-sm bg-black/20 p-4 rounded-2xl border border-white/5">
                  <p className="flex justify-between"><span className="text-on-surface-variant">الاسم:</span> <span className="font-bold">{order.details.name}</span></p>
                  <p className="flex justify-between"><span className="text-on-surface-variant">الهاتف:</span> <span className="font-bold">{order.details.phone}</span></p>
                  <p className="flex justify-between"><span className="text-on-surface-variant">العنوان:</span> <span className="font-bold">{order.details.country} - {order.details.governorate}</span></p>
                  <p className="text-xs opacity-70 bg-white/5 p-2 rounded-lg">{order.details.city} - {order.details.address}</p>
                  {order.details.locationUrl && (
                    <a href={order.details.locationUrl} target="_blank" className="bg-primary/10 text-primary flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-bold hover:bg-primary/20 transition-all">
                      <ExternalLink size={14} /> عرض الموقع على الخريطة
                    </a>
                  )}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2 pt-4 border-t border-white/5">
              <button 
                onClick={() => updateStatus(order.id, "received")}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${order.status === "received" ? "bg-primary text-on-primary shadow-lg shadow-primary/20" : "bg-white/5 hover:bg-white/10"}`}
              >
                تم الاستلام
              </button>
              <button 
                onClick={() => updateStatus(order.id, "processing")}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${order.status === "processing" ? "bg-amber-500 text-black shadow-lg shadow-amber-500/20" : "bg-white/5 hover:bg-white/10"}`}
              >
                جاري التجهيز
              </button>
              <button 
                onClick={() => updateStatus(order.id, "shipped")}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${order.status === "shipped" ? "bg-blue-500 text-white shadow-lg shadow-blue-500/20" : "bg-white/5 hover:bg-white/10"}`}
              >
                تم الشحن
              </button>
              <button 
                onClick={() => updateStatus(order.id, "delivered")}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${order.status === "delivered" ? "bg-green-500 text-white shadow-lg shadow-green-500/20" : "bg-white/5 hover:bg-white/10"}`}
              >
                تم التسليم
              </button>
              <button 
                onClick={() => updateStatus(order.id, "rejected")}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all ${order.status === "rejected" ? "bg-error text-white shadow-lg shadow-error/20" : "bg-white/5 hover:bg-white/10"}`}
              >
                مرفوض
              </button>
              <button 
                onClick={() => {
                  const statusMap: any = {
                    received: "تم الاستلام",
                    processing: "جاري التجهيز",
                    shipped: "تم الشحن",
                    delivered: "تم التسليم",
                    rejected: "مرفوض"
                  };
                  const text = `تحديث بخصوص طلبك #${order.id}\nالحالة الحالية: ${statusMap[order.status]}`;
                  window.open(`https://wa.me/${order.details.phone.replace(/\D/g, "")}?text=${encodeURIComponent(text)}`, "_blank");
                }}
                className="mr-auto flex items-center gap-2 bg-[#25D366] text-white px-5 py-2 rounded-xl text-[10px] font-bold hover:brightness-110 shadow-lg shadow-green-500/20"
              >
                <WhatsAppIcon size={14} /> مراسلة العميل
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Order Delete Confirmation */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-surface-container-high p-8 rounded-[40px] max-w-sm w-full text-center space-y-6 border border-white/10 shadow-2xl">
              <div className="w-20 h-20 bg-error/10 text-error rounded-full flex items-center justify-center mx-auto">
                <Trash2 size={40} />
              </div>
              <h3 className="text-xl font-bold">حذف الطلب؟</h3>
              <p className="text-on-surface-variant text-sm">هل أنت متأكد من حذف هذا الطلب نهائياً؟</p>
              <div className="flex gap-3">
                <button onClick={() => setShowDeleteConfirm(null)} className="flex-1 py-3 bg-surface-container-low rounded-full font-bold">إلغاء</button>
                <button onClick={() => deleteOrder(showDeleteConfirm)} className="flex-1 py-3 bg-error text-white rounded-full font-bold shadow-lg shadow-error/20">حذف</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}



export default function App() {
  const [view, setView] = useState<"home" | "products" | "cart" | "favorites" | "contact" | "checkout" | "invoice" | "admin" | "product-detail" | "orders">("home");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [products, setProducts] = useState<Product[]>(initialProducts as Product[]);
  const [slides, setSlides] = useState<HomeSlide[]>(initialSlides as HomeSlide[]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [orderDetails, setOrderDetails] = useState<OrderDetails | null>(null);
  const [adminPassword, setAdminPassword] = useState("774586524");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showHeader, setShowHeader] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [currency, setCurrency] = useState<CurrencyOption>(CURRENCIES[0]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);
  const [customerPhone, setCustomerPhone] = useState("");
  const [isOrdersLoggedIn, setIsOrdersLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [recognition, setRecognition] = useState<any>(null);
  const [completedOrdersCount, setCompletedOrdersCount] = useState(0);
  const [lastOrderItems, setLastOrderItems] = useState<CartItem[]>([]);
  const [lastOrderTotal, setLastOrderTotal] = useState(0);
  const [lastOrderId, setLastOrderId] = useState("");
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const formatPrice = (price: number) => {
    const converted = price * currency.rate;
    if (currency.code === "USD") {
      return converted.toFixed(2);
    }
    return Math.round(converted).toLocaleString();
  };

  // Keyboard Detection
  useEffect(() => {
    const handleResize = () => {
      // If height decreases significantly, keyboard is likely open
      if (window.innerHeight < 500) {
        setIsKeyboardOpen(true);
      } else {
        setIsKeyboardOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Search Logic
  useEffect(() => {
    if (searchQuery.trim() === "") {
      setSearchResults([]);
      return;
    }

    // Admin Login via Search Bar
    if (searchQuery === "774586524") {
      setIsAdminAuthenticated(true);
      setView("admin");
      setSearchQuery("");
      setIsSearchOpen(false);
      showMessage("تم الدخول للوحة التحكم", "success");
      return;
    }

    const results = products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
    ).slice(0, 5);
    setSearchResults(results);
  }, [searchQuery, products]);

  // Scroll Handler for Smart Header
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setShowHeader(false);
      } else {
        setShowHeader(true);
      }
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  // Fetch Admin Password
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const docRef = doc(db, "settings", "admin_config");
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          setAdminPassword(docSnap.data().password || "774586524");
        } else {
          // Only try to create if we are admin or it's first run
          // But allow read: if true should have worked for getDoc
          await setDoc(docRef, { password: "774586524" });
        }
      } catch (error) {
        console.error("Error fetching settings:", error);
        // Fallback to default
        setAdminPassword("774586524");
      }
    };
    fetchSettings();
  }, []);

  // Auto-authenticate if Google user is admin
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const docRef = doc(db, "settings", "admin_config");
          const docSnap = await getDoc(docRef);
          const adminEmails = docSnap.exists() ? docSnap.data().adminEmails || ["yahyaalbnaa6@gmail.com"] : ["yahyaalbnaa6@gmail.com"];
          
          if (adminEmails.includes(user.email)) {
            setIsAdminAuthenticated(true);
          } else {
            setIsAdminAuthenticated(false);
          }
        } catch (err) {
          // Fallback
          if (user.email === "yahyaalbnaa6@gmail.com") {
            setIsAdminAuthenticated(true);
          } else {
            setIsAdminAuthenticated(false);
          }
        }
      } else {
        setIsAdminAuthenticated(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const startVoiceSearch = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showMessage("متصفحك لا يدعم البحث الصوتي", "error");
      return;
    }

    // If already listening, stop it
    if (isListening) {
      stopVoiceSearch();
      return;
    }

    const rec = new SpeechRecognition();
    rec.lang = 'ar-SA';
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.continuous = false;

    rec.onstart = () => {
      setIsListening(true);
      // Removed showMessage here to avoid cluttering the UI
    };

    rec.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setSearchQuery(transcript);
      setIsSearchOpen(true);
      setIsListening(false);
      showMessage(`تم التعرف على: ${transcript}`, "success");
    };

    rec.onerror = (event: any) => {
      setIsListening(false);
      console.error("Speech Recognition Error:", event.error);
      if (event.error === 'not-allowed') {
        showMessage("يرجى السماح بالوصول للميكروفون", "error");
      } else if (event.error === 'no-speech') {
        showMessage("لم يتم سماع أي صوت", "info");
      } else {
        showMessage("فشل التعرف على الصوت", "error");
      }
    };

    rec.onend = () => {
      setIsListening(false);
    };

    setRecognition(rec);
    try {
      rec.start();
    } catch (err) {
      console.error("Recognition start error:", err);
      setIsListening(false);
    }
  };

  const stopVoiceSearch = () => {
    if (recognition) {
      recognition.stop();
      setIsListening(false);
      showMessage("تم إيقاف الاستماع", "info");
    }
  };

  // Calculate completed orders for loyalty
  useEffect(() => {
    if (currentUser) {
      const count = orders.filter(o => o.userId === currentUser.uid && o.status === "delivered").length;
      setCompletedOrdersCount(count);
    } else {
      setCompletedOrdersCount(0);
    }
  }, [orders, currentUser]);

  useEffect(() => {
    // Listen for products
    const unsubscribeProducts = onSnapshot(
      query(collection(db, "products")),
      (snapshot) => {
        const productsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
        if (productsData.length > 0) {
          setProducts(productsData);
        } else {
          // Initialize with defaults if empty
          initialProducts.forEach(async (p: any) => {
            const newDoc = doc(collection(db, "products"));
            await setDoc(newDoc, sanitizeForFirestore({ ...p, id: newDoc.id, active: true }));
          });
        }
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "products")
    );

    // Listen for slides
    const unsubscribeSlides = onSnapshot(
      collection(db, "slides"),
      (snapshot) => {
        const slidesData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as HomeSlide));
        if (slidesData.length > 0) {
          setSlides(slidesData);
        } else {
          // Initialize with defaults
          initialSlides.forEach(async (s: any) => {
            const newDoc = doc(collection(db, "slides"));
            await setDoc(newDoc, sanitizeForFirestore({ ...s, id: newDoc.id }));
          });
        }
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "slides")
    );

    // Listen for orders (Admin only)
    const unsubscribeOrders = onSnapshot(
      query(collection(db, "orders"), orderBy("date", "desc")),
      (snapshot) => {
        const ordersData = snapshot.docs.map(doc => ({ ...doc.data() } as Order));
        setOrders(ordersData);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "orders")
    );

    const savedCart = localStorage.getItem("cart");
    if (savedCart) setCart(JSON.parse(savedCart));

    const savedFavs = localStorage.getItem("favorites");
    if (savedFavs) setFavorites(JSON.parse(savedFavs));
    
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) setIsDarkMode(savedTheme === "dark");

    const savedCurrency = localStorage.getItem("currency");
    if (savedCurrency) {
      const found = CURRENCIES.find(c => c.code === savedCurrency);
      if (found) setCurrency(found);
    }

    return () => {
      unsubscribeProducts();
      unsubscribeSlides();
      unsubscribeOrders();
    };
  }, [isAdminAuthenticated]);

  // Remove sample orders effect
  useEffect(() => {
    // Sample orders are no longer needed
  }, []);

  // Save Data
  useEffect(() => {
    localStorage.setItem("currency", currency.code);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    localStorage.setItem("theme", isDarkMode ? "dark" : "light");
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [isDarkMode]);

  // Actions
  const addToCart = (product: Product, quantity: number = 1, size?: { label: string, price: number }) => {
    setCart(prev => {
      const priceToUse = size ? size.price : product.price;
      const existing = prev.find(item => item.id === product.id && item.selectedSize === size?.label);
      if (existing) {
        showMessage("تم تحديث الكمية في السلة", "info");
        return prev.map(item => (item.id === product.id && item.selectedSize === size?.label) ? { ...item, quantity: item.quantity + quantity } : item);
      }
      showMessage("تمت الإضافة للسلة بنجاح", "success");
      return [...prev, { ...product, quantity, selectedSize: size?.label, finalPrice: priceToUse }];
    });
  };

  const removeFromCart = (id: string, size?: string) => {
    setCart(prev => prev.filter(item => !(item.id === id && item.selectedSize === size)));
    showMessage("تمت الإزالة من السلة", "info");
  };

  const updateQuantity = (id: string, size: string | undefined, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id && item.selectedSize === size) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const toggleFavorite = (id: string) => {
    const isFav = favorites.includes(id);
    setFavorites(prev => isFav ? prev.filter(fid => fid !== id) : [...prev, id]);
    showMessage(isFav ? "تمت الإزالة من المفضلة" : "تمت الإضافة للمفضلة", "error");
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.finalPrice * item.quantity, 0);

  const [message, setMessage] = useState<{ text: string, type: "success" | "error" | "info" } | null>(null);

  const showMessage = (text: string, type: "success" | "error" | "info" = "info") => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  // @ts-ignore
  window.showMessage = showMessage;

  const handleCheckout = async (details: OrderDetails) => {
    const isLoyaltyEligible = completedOrdersCount === 3; // Only on the 4th order
    const discount = isLoyaltyEligible ? totalAmount * 0.2 : 0;
    const finalTotal = totalAmount - discount;

    // Sequential Order Numbering using Firestore counter
    let orderId = "";
    try {
      const counterRef = doc(db, "counters", "orders");
      const counterSnap = await getDoc(counterRef);
      let nextId = 1;
      if (counterSnap.exists()) {
        nextId = (counterSnap.data().count || 0) + 1;
      }
      await setDoc(counterRef, { count: nextId }, { merge: true });
      orderId = nextId.toString();
    } catch (err) {
      console.error("Counter Error:", err);
      orderId = (Date.now() % 1000000).toString(); // Fallback
    }
    
    // We don't save to Firestore yet, just prepare for Invoice
    setLastOrderItems([...cart]);
    setLastOrderTotal(finalTotal);
    setLastOrderId(orderId);
    setOrderDetails(details);
    setView("invoice");
    
    // We clear the cart but keep the items in lastOrderItems for the invoice and WhatsApp
    setCart([]);
    localStorage.removeItem("cart");
    
    if (isLoyaltyEligible) {
      showMessage("تم تطبيق خصم نقاط النحل 20%!", "success");
    } else {
      showMessage("تم تجهيز فاتورتك بنجاح", "success");
    }
  };

  const sendToWhatsApp = async () => {
    if (!orderDetails || lastOrderItems.length === 0) return;
    
    const itemsText = lastOrderItems.map(item => `- ${item.name} ${item.selectedSize ? `(${item.selectedSize})` : ""} (${item.quantity}x) - ${formatPrice(item.finalPrice * item.quantity)} ${currency.symbol}`).join("\n");
    const locationText = orderDetails.locationUrl ? `\n*الموقع:* ${orderDetails.locationUrl}` : "";
    const addressText = `*الدولة:* ${orderDetails.country}\n${orderDetails.governorate ? `*المحافظة:* ${orderDetails.governorate}\n` : ""}*المدينة/المنطقة:* ${orderDetails.city}\n*العنوان:* ${orderDetails.address}`;
    
    const text = `*طلب جديد من متجر الشهابي الحضرمي*\n\n*رقم الطلب:* #${lastOrderId}\n*العميل:* ${orderDetails.name}\n*الهاتف:* ${orderDetails.phone}\n${addressText}${locationText}\n\n*المنتجات:*\n${itemsText}\n\n*الإجمالي:* ${formatPrice(lastOrderTotal)} ${currency.symbol}\n*طريقة الدفع:* ${orderDetails.paymentMethod}\n\n*ملاحظات:* ${orderDetails.notes || "لا يوجد"}`;
    
    // Save to Firestore ONLY when sending to WhatsApp
    const newOrder: Order = {
      id: lastOrderId,
      date: new Date().toISOString(),
      details: orderDetails,
      items: lastOrderItems,
      total: lastOrderTotal,
      status: "received",
      currency,
      // @ts-ignore
      userId: currentUser?.uid || null,
      // @ts-ignore
      discountAmount: completedOrdersCount >= 3 ? (lastOrderTotal / 0.8) * 0.2 : 0,
      // @ts-ignore
      isLoyaltyOrder: completedOrdersCount >= 3
    };

    try {
      // Open WhatsApp first as requested
      window.open(`https://wa.me/967774586524?text=${encodeURIComponent(text)}`, "_blank");
      
      // Then save to Firestore
      await setDoc(doc(db, "orders", newOrder.id), sanitizeForFirestore(newOrder));
      showMessage("تم إرسال الطلب بنجاح", "success");
    } catch (error) {
      console.error("Firestore Save Error:", error);
      handleFirestoreError(error, OperationType.CREATE, "orders");
    }
  };

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <ErrorBoundary>
      <div className={`${isDarkMode ? "dark" : ""} min-h-screen transition-colors duration-700`}>
      <div className="bg-background text-on-surface font-body selection:bg-primary/30 min-h-screen pb-24 relative overflow-hidden">
        
        {/* Honeycomb Background */}
        <div className="fixed inset-0 honeycomb-bg pointer-events-none z-0" />

        {/* Theme Transition Overlay */}
        <AnimatePresence>
          <motion.div
            key={isDarkMode ? "dark-circle" : "light-circle"}
            initial={{ scale: 0, opacity: 0.5 }}
            animate={{ scale: 4, opacity: 0 }}
            transition={{ duration: 0.8, ease: "circOut" }}
            className="fixed top-8 left-[calc(100%-40px)] -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-primary/20 pointer-events-none z-[100]"
          />
        </AnimatePresence>

        {/* Toast Message */}
        <AnimatePresence>
          {message && (
            <motion.div 
              initial={{ opacity: 0, y: -50, x: "-50%" }}
              animate={{ opacity: 1, y: 0, x: "-50%" }}
              exit={{ opacity: 0, y: -50, x: "-50%" }}
              className={`fixed top-20 left-1/2 z-[100] px-6 py-3 rounded-full shadow-2xl font-bold flex items-center gap-2 whitespace-nowrap ${
                message.type === "success" ? "bg-green-500 text-white" : 
                message.type === "error" ? "bg-red-600 text-white" : "bg-primary text-on-primary"
              }`}
            >
              {message.type === "success" && <CheckCircle2 size={18} />}
              {message.text}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Search Overlay */}
        <AnimatePresence>
          {isSearchOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/95 backdrop-blur-xl z-[100] p-6 flex flex-col"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="relative flex-1">
                  <input 
                    autoFocus
                    type="text"
                    placeholder="ابحث عن عسل، مكسرات..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-surface-container-high border border-white/10 rounded-2xl py-4 px-12 text-lg focus:outline-none focus:border-primary/50 transition-all text-right"
                  />
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-primary" size={24} />
                  <button 
                    onClick={startVoiceSearch}
                    className={`absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full transition-all ${isListening ? "text-primary animate-pulse bg-primary/20" : "text-on-surface-variant hover:text-primary"}`}
                  >
                    <Mic size={24} />
                  </button>
                </div>
                <button 
                  onClick={() => {
                    setIsSearchOpen(false);
                    setSearchQuery("");
                  }}
                  className="w-12 h-12 flex items-center justify-center bg-surface-container-high rounded-2xl text-on-surface-variant"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4">
                {searchResults.length > 0 ? (
                  searchResults.map(product => (
                    <button 
                      key={product.id}
                      onClick={() => {
                        setSelectedProduct(product);
                        setView("product-detail");
                        setIsSearchOpen(false);
                        setSearchQuery("");
                      }}
                      className="w-full flex items-center gap-4 p-4 bg-surface-container-low rounded-3xl border border-white/5 shadow-lg text-right"
                    >
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-16 h-16 rounded-2xl object-cover shadow-md" 
                        loading="lazy" 
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1">
                        <div className="font-bold text-lg text-on-surface">{product.name}</div>
                        <div className="text-xs text-primary font-bold">{product.category}</div>
                        <div className="text-sm font-bold mt-1">{formatPrice(product.price)} {currency.symbol}</div>
                      </div>
                      <ChevronLeft size={20} className="text-on-surface-variant" />
                    </button>
                  ))
                ) : searchQuery.trim() !== "" ? (
                  <div className="text-center py-20 text-on-surface-variant">
                    <p>لا توجد نتائج لـ "{searchQuery}"</p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <h4 className="font-bold text-on-surface-variant px-2">اقتراحات شائعة</h4>
                    <div className="flex flex-wrap gap-2">
                      {["عسل سدر", "مكسرات", "خلطات", "زبيب"].map(tag => (
                        <button 
                          key={tag}
                          onClick={() => setSearchQuery(tag)}
                          className="px-6 py-3 bg-surface-container-high rounded-full text-sm font-bold hover:bg-primary hover:text-on-primary transition-all"
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sidebar Overlay */}
        <AnimatePresence>
          {isSidebarOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsSidebarOpen(false)}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
              />
              <motion.aside
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="fixed top-0 right-0 h-full w-72 bg-background/30 backdrop-blur-3xl z-[70] shadow-[0_0_50px_rgba(0,0,0,0.5)] border-l border-white/10 p-8 flex flex-col overflow-y-auto hide-scrollbar"
              >
                <div className="flex justify-between items-center mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary/20 rounded-2xl flex items-center justify-center shadow-xl shadow-primary/10 border border-primary/30">
                      <Logo />
                    </div>
                    <h3 className="font-headline font-bold text-xl text-primary">الشهابي</h3>
                  </div>
                  <button onClick={() => setIsSidebarOpen(false)} className="text-on-surface-variant hover:text-primary transition-colors p-2 hover:bg-white/5 rounded-xl"><X size={24} /></button>
                </div>

                <div className="mb-8 space-y-2">
                  <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-widest px-2">اختر العملة</p>
                  <div className="grid grid-cols-2 gap-2">
                    {CURRENCIES.map(c => (
                      <button 
                        key={c.code}
                        onClick={() => setCurrency(c)}
                        className={`px-3 py-2 rounded-xl text-[10px] font-bold transition-all border ${currency.code === c.code ? "bg-primary text-on-primary border-primary shadow-lg shadow-primary/20" : "bg-white/5 text-on-surface-variant border-white/10 hover:bg-white/10"}`}
                      >
                        {c.label}
                      </button>
                    ))}
                  </div>
                </div>

                <nav className="flex-1 space-y-3">
                  <SidebarItem icon={<Home size={20} />} label="الرئيسية" onClick={() => { setView("home"); setIsSidebarOpen(false); }} active={view === "home"} />
                  <SidebarItem icon={<Menu size={20} />} label="المنتجات" onClick={() => { setView("products"); setIsSidebarOpen(false); }} active={view === "products"} />
                  <SidebarItem icon={<ShoppingBag size={20} />} label="السلة" onClick={() => { setView("cart"); setIsSidebarOpen(false); }} active={view === "cart"} />
                  <SidebarItem icon={<Heart size={20} />} label="المفضلة" onClick={() => { setView("favorites"); setIsSidebarOpen(false); }} active={view === "favorites"} />
                  <SidebarItem icon={<Headset size={20} />} label="تواصل معنا" onClick={() => { setView("contact"); setIsSidebarOpen(false); }} active={view === "contact"} />
                  <SidebarItem icon={<ShoppingBag size={20} />} label="طلباتي السابقة" onClick={() => { setView("orders"); setIsSidebarOpen(false); }} active={view === "orders"} />
                  <SidebarItem icon={<Settings size={20} />} label="حسابي" onClick={() => { setView("account"); setIsSidebarOpen(false); }} active={view === "account"} />
                  <SidebarItem icon={<Star size={20} className="text-primary" />} label="نقاط النحل" onClick={() => { setView("account"); setIsSidebarOpen(false); }} active={false} />
                </nav>
                <div className="mt-auto pt-6 space-y-4">
                  <button 
                    onClick={toggleTheme}
                    className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/5 text-on-surface-variant hover:bg-primary/10 hover:text-primary transition-all border border-white/10"
                  >
                    {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
                    <span className="font-bold">{isDarkMode ? "الوضع الفاتح" : "الوضع الداكن"}</span>
                  </button>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Header */}
        {view !== "admin" && (
          <motion.header 
            initial={{ y: 0 }}
            animate={{ y: showHeader ? 0 : -100 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="fixed top-0 w-full z-50 bg-background/60 backdrop-blur-2xl flex justify-between items-center px-6 h-20 shadow-sm border-b border-white/5"
          >
            <button onClick={() => setIsSidebarOpen(true)} className="text-primary hover:opacity-80 transition-opacity active:scale-95 duration-200 p-2 bg-primary/10 rounded-xl">
              <Menu size={24} />
            </button>
            
            <div onClick={() => setView("home")} className="flex items-center gap-3 cursor-pointer group">
              <div className="w-16 h-16 bg-primary/5 rounded-2xl flex items-center justify-center shadow-2xl shadow-primary/5 group-hover:scale-110 transition-all duration-500 overflow-hidden border border-primary/10 p-2">
                <Logo />
              </div>
              <div className="hidden md:block">
                <h1 className="font-headline font-bold text-2xl tracking-tight text-on-surface">الشهابي</h1>
                <p className="text-[10px] text-primary font-bold tracking-widest uppercase opacity-80">للعسل الحضرمي</p>
              </div>
            </div>

            {/* Search Bar Desktop */}
            <div className="relative flex-1 max-w-md mx-8 hidden lg:block">
              <div className="relative group">
                <input 
                  type="text"
                  placeholder="ابحث عن عسل، مكسرات..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-surface-container-high border border-white/10 rounded-2xl py-3 px-12 text-sm focus:outline-none focus:border-primary/50 transition-all shadow-inner text-right"
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant group-focus-within:text-primary transition-colors" size={20} />
                <button 
                  onClick={startVoiceSearch}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-xl transition-all ${isListening ? "text-primary animate-pulse bg-primary/20 shadow-[0_0_15px_rgba(var(--primary-rgb),0.3)]" : "text-on-surface-variant hover:text-primary hover:bg-white/5"}`}
                  title="بحث صوتي"
                >
                  <Mic size={22} />
                </button>
              </div>
              
              {/* Suggestions */}
              <AnimatePresence>
                {searchResults.length > 0 && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full left-0 right-0 mt-2 bg-surface-container-high border border-white/10 rounded-[32px] shadow-2xl overflow-hidden z-[60] backdrop-blur-xl"
                  >
                    {searchResults.map(product => (
                      <button 
                        key={product.id}
                        onClick={() => {
                          setSelectedProduct(product);
                          setView("product-detail");
                          setSearchQuery("");
                        }}
                        className="w-full flex items-center gap-4 p-4 hover:bg-primary/10 transition-colors text-right border-b border-white/5 last:border-0"
                      >
                        <img 
                          src={product.image} 
                          alt={product.name} 
                          className="w-12 h-12 rounded-xl object-cover shadow-md" 
                          loading="lazy" 
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1">
                          <div className="font-bold text-sm text-on-surface">{product.name}</div>
                          <div className="text-[10px] text-primary font-bold">{product.category}</div>
                        </div>
                        <div className="text-sm font-bold text-primary">{product.price} ر.ي</div>
                      </button>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="lg:hidden w-12 h-12 flex items-center justify-center text-primary bg-primary/10 hover:bg-primary/20 rounded-2xl transition-all active:scale-90 duration-200 border border-primary/20"
              >
                <Search size={22} />
              </button>
              
              <button 
                onClick={toggleTheme} 
                className="relative w-12 h-12 flex items-center justify-center text-primary bg-primary/10 hover:bg-primary/20 rounded-2xl transition-all active:scale-90 duration-200 overflow-hidden border border-primary/20"
              >
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={isDarkMode ? "dark" : "light"}
                    initial={{ y: 20, opacity: 0, rotate: -45 }}
                    animate={{ y: 0, opacity: 1, rotate: 0 }}
                    exit={{ y: -20, opacity: 0, rotate: 45 }}
                    transition={{ duration: 0.3, ease: "backOut" }}
                  >
                    {isDarkMode ? <Sun size={22} /> : <Moon size={22} />}
                  </motion.div>
                </AnimatePresence>
              </button>
            </div>
          </motion.header>
        )}

        {/* Main Content */}
        <main className={`${view === "admin" ? "pt-4" : "pt-20"} px-4 max-w-4xl mx-auto`}>
          <AnimatePresence mode="wait">
            {view === "home" && <HomeView products={products} setView={setView} addToCart={addToCart} toggleFavorite={toggleFavorite} favorites={favorites} setSelectedProduct={setSelectedProduct} slides={slides} setFullScreenImage={setFullScreenImage} showMessage={showMessage} currency={currency} formatPrice={formatPrice} completedOrdersCount={completedOrdersCount} />}
            {view === "products" && <ProductsView products={products} addToCart={addToCart} toggleFavorite={toggleFavorite} favorites={favorites} setView={setView} setSelectedProduct={setSelectedProduct} setFullScreenImage={setFullScreenImage} currency={currency} formatPrice={formatPrice} />}
            {view === "product-detail" && selectedProduct && <ProductDetailView product={selectedProduct} products={products} addToCart={addToCart} setView={setView} toggleFavorite={toggleFavorite} isFavorite={favorites.includes(selectedProduct.id)} favorites={favorites} setFullScreenImage={setFullScreenImage} showMessage={showMessage} currency={currency} formatPrice={formatPrice} setSelectedProduct={setSelectedProduct} />}
            {view === "cart" && <CartView cart={cart} updateQuantity={updateQuantity} removeFromCart={removeFromCart} total={totalAmount} setView={setView} currency={currency} formatPrice={formatPrice} setSelectedProduct={setSelectedProduct} />}
            {view === "favorites" && <FavoritesView products={products} favorites={favorites} toggleFavorite={toggleFavorite} addToCart={addToCart} setView={setView} setSelectedProduct={setSelectedProduct} setFullScreenImage={setFullScreenImage} currency={currency} formatPrice={formatPrice} />}
            {view === "contact" && <ContactView />}
            {view === "checkout" && <CheckoutView total={totalAmount} onConfirm={handleCheckout} cart={cart} currency={currency} formatPrice={formatPrice} />}
            {view === "invoice" && orderDetails && <InvoiceView orderDetails={orderDetails} cart={lastOrderItems} total={lastOrderTotal} orderId={lastOrderId} onSend={sendToWhatsApp} currency={currency} formatPrice={formatPrice} setView={setView} />}
            {view === "orders" && <OrdersView formatPrice={formatPrice} addToCart={addToCart} currentUser={currentUser} setView={setView} showMessage={showMessage} />}
            {view === "account" && <AccountView currentUser={currentUser} showMessage={showMessage} setView={setView} completedOrdersCount={completedOrdersCount} setShowLogoutConfirm={setShowLogoutConfirm} />}
            {view === "admin" && (
              <AdminView 
                products={products} 
                setProducts={setProducts} 
                slides={slides}
                setSlides={setSlides}
                orders={orders}
                setOrders={setOrders}
                formatPrice={formatPrice}
                isAuthenticated={isAdminAuthenticated} 
                setIsAuthenticated={setIsAdminAuthenticated} 
                adminPassword={adminPassword}
                setAdminPassword={setAdminPassword}
                showMessage={showMessage} 
                setView={setView}
              />
            )}

            {/* 404 Fallback */}
            {!["home", "products", "cart", "checkout", "invoice", "account", "orders", "contact", "admin", "favorites", "product-detail"].includes(view) && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-20 text-center space-y-6">
                <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Search size={48} className="text-primary" />
                </div>
                <h2 className="text-3xl font-bold">عذراً، الصفحة غير موجودة</h2>
                <p className="text-on-surface-variant">يبدو أنك ضللت الطريق في عالم العسل</p>
                <button onClick={() => setView("home")} className="bg-primary text-on-primary px-8 py-3 rounded-full font-bold shadow-lg">العودة للرئيسية</button>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Bottom Navigation */}
        {!isKeyboardOpen && view !== "admin" && (
          <nav className="fixed bottom-0 w-full z-50 rounded-t-[32px] bg-background/90 backdrop-blur-xl flex justify-around items-center px-4 h-16 pb-safe shadow-[0_-10px_30px_0_rgba(0,0,0,0.3)] border-t border-white/5">
            <NavItem icon={<Home size={20} />} label="الرئيسية" active={view === "home"} onClick={() => setView("home")} />
            <NavItem icon={<Menu size={20} />} label="المنتجات" active={view === "products"} onClick={() => setView("products")} />
            <NavItem icon={<div className="relative"><ShoppingBag size={20} />{cart.length > 0 && <span className="absolute -top-1.5 -right-1.5 bg-primary text-on-primary text-[8px] w-4 h-4 rounded-full flex items-center justify-center font-bold shadow-lg shadow-primary/30">{cart.length}</span>}</div>} label="السلة" active={view === "cart"} onClick={() => setView("cart")} />
            <NavItem icon={<Heart size={20} />} label="المفضلة" active={view === "favorites"} onClick={() => setView("favorites")} />
            <NavItem icon={<Headset size={20} />} label="تواصل معنا" active={view === "contact"} onClick={() => setView("contact")} />
          </nav>
        )}

        {/* Floating WhatsApp */}
        <motion.a 
          href="https://wa.me/967774586524" 
          target="_blank" 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="fixed bottom-24 right-6 w-14 h-14 bg-[#25D366] text-white rounded-full flex items-center justify-center shadow-2xl shadow-green-500/40 z-40 animate-float"
        >
          <WhatsAppIcon size={28} />
        </motion.a>

        {/* Logout Confirmation Modal */}
        <AnimatePresence>
          {showLogoutConfirm && (
            <div className="fixed inset-0 z-[300] bg-black/20 backdrop-blur-sm flex items-center justify-center p-6">
              <motion.div 
                initial={{ scale: 0.9, opacity: 0, y: 20 }} 
                animate={{ scale: 1, opacity: 1, y: 0 }} 
                exit={{ scale: 0.9, opacity: 0, y: 20 }} 
                className="bg-white/60 backdrop-blur-md p-8 rounded-[40px] max-w-sm w-full text-center space-y-6 relative overflow-hidden shadow-2xl border border-white/40"
              >
                <div className="absolute -top-10 -right-10 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto relative">
                  <User size={32} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-headline font-black">هل ستغادرنا؟</h3>
                  <p className="text-on-surface-variant text-xs leading-relaxed">
                    نحن دائماً بانتظار عودتك لتذوق أجود أنواع العسل الحضرمي. هل أنت متأكد من تسجيل الخروج؟
                  </p>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setShowLogoutConfirm(false)} 
                    className="flex-1 py-3 bg-white/5 rounded-2xl font-bold hover:bg-white/10 transition-all text-sm"
                  >
                    البقاء
                  </button>
                  <button 
                    onClick={async () => {
                      await auth.signOut();
                      setShowLogoutConfirm(false);
                      showMessage("وداعاً.. ننتظر عودتك قريباً", "info");
                    }} 
                    className="flex-1 py-3 bg-primary text-on-primary rounded-2xl font-bold shadow-lg shadow-primary/20 hover:scale-105 transition-all text-sm"
                  >
                    خروج
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Voice Search Overlay */}
        <AnimatePresence>
          {isListening && (
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[300] bg-black/95 backdrop-blur-2xl flex flex-col items-center justify-center p-6 text-center"
            >
              <div className="relative mb-16">
                <motion.div 
                  animate={{ scale: [1, 2, 1], opacity: [0.3, 0.1, 0.3] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                  className="absolute inset-0 bg-primary rounded-full blur-[60px]"
                />
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                  onClick={stopVoiceSearch}
                  className="relative w-40 h-40 bg-primary text-on-primary rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(var(--primary-rgb),0.5)] cursor-pointer hover:scale-105 transition-transform"
                >
                  <Mic size={64} className="animate-pulse" />
                </motion.div>
              </div>
              
              <h2 className="text-4xl font-headline font-black text-white mb-6">جاري الاستماع...</h2>
              <p className="text-white/70 mb-16 max-w-xs text-lg">تحدث الآن للبحث عن منتجات العسل والمكسرات</p>
              
              <button 
                onClick={stopVoiceSearch}
                className="px-12 py-6 bg-error text-white rounded-full font-black text-2xl shadow-2xl shadow-error/40 hover:scale-110 active:scale-90 transition-all border-4 border-white/20 flex items-center gap-4"
              >
                <X size={32} /> إيقاف الميكروفون
              </button>
              <p className="mt-6 text-error/80 font-bold text-sm tracking-widest uppercase">انقر للعودة</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Full Screen Image Modal */}
        <AnimatePresence>
          {fullScreenImage && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-4"
            >
              <button 
                onClick={() => setFullScreenImage(null)}
                className="absolute top-6 right-6 text-white/70 hover:text-white p-2 bg-white/10 rounded-full transition-all"
              >
                <X size={32} />
              </button>

              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="relative max-w-4xl w-full aspect-square md:aspect-video rounded-3xl overflow-hidden shadow-2xl border border-white/10"
              >
                <img 
                  src={fullScreenImage} 
                  className="w-full h-full object-contain" 
                  alt="Full screen product view" 
                  referrerPolicy="no-referrer"
                />
              </motion.div>

              <div className="mt-8 flex gap-4">
                <button 
                  onClick={async () => {
                    try {
                      // @ts-ignore
                      window.showMessage("جاري التحميل...", "info");
                      const response = await fetch(fullScreenImage);
                      const blob = await response.blob();
                      const url = window.URL.createObjectURL(blob);
                      const link = document.createElement('a');
                      link.href = url;
                      link.download = `alshahabi-${Date.now()}.jpg`;
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                      window.URL.revokeObjectURL(url);
                      // @ts-ignore
                      window.showMessage("تم التحميل بنجاح", "success");
                    } catch (error) {
                      console.error("Download failed:", error);
                      const link = document.createElement('a');
                      link.href = fullScreenImage;
                      link.target = "_blank";
                      link.download = 'honey-image.jpg';
                      link.click();
                      // @ts-ignore
                      window.showMessage("تم فتح الصورة في نافذة جديدة للتحميل", "info");
                    }
                  }}
                  className="px-8 py-4 bg-primary text-on-primary rounded-full font-bold flex items-center gap-2 shadow-xl shadow-primary/30 hover:scale-105 active:scale-95 transition-all"
                >
                  <Download size={20} /> تحميل الصورة
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
    </ErrorBoundary>
  );
}



// --- Sub-Views ---



function HomeView({ products, setView, addToCart, toggleFavorite, favorites, setSelectedProduct, slides, setFullScreenImage, showMessage, currency, formatPrice, completedOrdersCount }: any) {
  const offers = products.filter((p: Product) => p.isOffer && p.active);
  const featured = products.filter((p: Product) => p.active).slice(0, 4);
  
  const reviews = [
    { name: "صالح اليافعي", text: "ما شاء الله على ذا السدر، طعمه يشرح الخاطر ويرد الروح. والله ما ذقت مثله بحياتي. جودة تبيض الوجه وتوصيلهم سريع عادهم.", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Saleh" },
    { name: "أم محمد", text: "تبارك الرحمن، العسل صافي ومضمون ميه بالميه. جربته لعيالي والحمدلله نفعهم واجد. الله يبارك لكم في حلالكم.", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=UmMohamed" },
    { name: "عبدالله الحضرمي", text: "عسل الشهابي معروف من زمان، أهل جودة وأمانة. الصدق إنهم يبيضون الوجه وعسلهم دواء. يستاهل كل بيسة تدفع فيه.", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Abdullah" },
    { name: "فاطمة عدن", text: "التغليف مرتب والخدمة ممتازة. العسل ثقيل وطعمه حالي بالحيل. كثر الله خيركم على ذا الشغل النظيف.", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Fatima" },
    { name: "سعيد المنهالي", text: "جربت السمر حقهم، شي فاخر من الآخر. ريحة وطعم وقوام. أنصح كل واحد يدور الزين يمر عليهم.", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Saeed" }
  ];

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="space-y-24 pb-20"
    >
      {/* Hero Section */}
      <section className="relative h-[90vh] -mt-20 -mx-4 overflow-hidden">
        <div className="absolute inset-0">
          <motion.img 
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
            transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
            src="https://images.unsplash.com/photo-1587049352846-4a222e784d38?q=80&w=2000&auto=format&fit=crop" 
            className="w-full h-full object-cover" 
            alt="Hero Honey" 
          />
          <div className="absolute inset-0 bg-gradient-to-l from-black/90 via-black/50 to-transparent" />
        </div>
        
        <div className="relative h-full max-w-7xl mx-auto px-6 flex flex-col justify-center items-start text-right space-y-8">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="space-y-4"
          >
            <span className="inline-block px-4 py-1.5 bg-primary/20 backdrop-blur-md border border-primary/30 text-primary rounded-full text-xs font-black tracking-[0.2em] uppercase">
              تراث حضرمي أصيل
            </span>
            <h1 className="text-6xl md:text-8xl font-headline font-black text-white leading-[1.1]">
              نقاء الطبيعة <br/>
              <span className="text-primary italic">في كل قطرة</span>
            </h1>
            <p className="text-white/70 text-lg md:text-xl max-w-xl leading-relaxed font-medium">
              نقدم لكم أجود أنواع العسل اليمني المستخلص بعناية من قلب الوديان، لنجمع بين الشفاء واللذة في منتج واحد.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="flex flex-wrap gap-4"
          >
            <button 
              onClick={() => setView("products")}
              className="px-10 py-5 bg-primary text-on-primary rounded-full font-black text-lg shadow-2xl shadow-primary/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-3"
            >
              تسوق الآن <ArrowLeft size={24} />
            </button>
            <button 
              onClick={() => {
                const el = document.getElementById('benefits');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="px-10 py-5 bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full font-black text-lg hover:bg-white/20 transition-all"
            >
              اكتشف الفوائد
            </button>
          </motion.div>
        </div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-white/30">
          <ChevronRight className="rotate-90" size={32} />
        </div>
      </section>

      {/* Categories Bento Grid */}
      <section className="max-w-7xl mx-auto px-4 py-16 space-y-12">
        <div className="text-center space-y-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full border border-primary/20"
          >
            <Star size={14} className="text-primary fill-primary" />
            <span className="text-[10px] font-black text-primary uppercase tracking-widest">منتجاتنا المختارة</span>
          </motion.div>
          <h2 className="text-4xl md:text-6xl font-headline font-black">اكتشف مجموعتنا</h2>
          <p className="text-on-surface-variant text-lg max-w-2xl mx-auto">نختار لك الأفضل من خيرات الأرض اليمنية، بجودة تليق بذائقتكم الرفيعة.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 min-h-[400px] md:min-h-[480px]">
          <motion.div 
            whileHover={{ scale: 1.01 }}
            onClick={() => setView("products")}
            className="md:col-span-2 relative rounded-[32px] overflow-hidden cursor-pointer group shadow-2xl"
          >
            <motion.img 
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              src="https://images.unsplash.com/photo-1471943311424-646960669fbc?q=80&w=1000&auto=format&fit=crop" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
              alt="" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-8 flex flex-col justify-end">
              <h3 className="text-3xl font-headline font-black text-white mb-1">العسل الملكي</h3>
              <p className="text-white/70 text-sm">أجود أنواع السدر والسمر الحضرمي الفاخر</p>
            </div>
          </motion.div>
          <div className="grid grid-rows-2 gap-4">
            <motion.div 
              whileHover={{ scale: 1.02, y: -5 }}
              onClick={() => setView("products")}
              className="relative rounded-[32px] overflow-hidden cursor-pointer group shadow-xl"
            >
              <img src="https://images.unsplash.com/photo-1530601763919-807df99c46f8?q=80&w=1000&auto=format&fit=crop" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-6 flex flex-col justify-end">
                <h3 className="text-xl font-headline font-black text-white mb-1">المكسرات الفاخرة</h3>
                <p className="text-white/70 text-xs">طاقة ونكهة لا تقاوم من أجود المحاصيل</p>
              </div>
            </motion.div>
            <motion.div 
              whileHover={{ scale: 1.02, y: -5 }}
              onClick={() => setView("products")}
              className="relative rounded-[32px] overflow-hidden cursor-pointer group shadow-xl"
            >
              <img src="https://images.unsplash.com/photo-1559339352-11d035aa65de?q=80&w=1000&auto=format&fit=crop" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent p-6 flex flex-col justify-end">
                <h3 className="text-xl font-headline font-black text-white mb-1">الخلطات العلاجية</h3>
                <p className="text-white/70 text-xs">وصفات طبيعية متوارثة للصحة والنشاط</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-4 py-12 md:py-20">
        <div className="bg-surface-container-low rounded-[32px] p-6 md:p-10 border border-white/5 luxury-shadow grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-10">
          {[
            { label: "سنة من الخبرة", value: "+50" },
            { label: "عميل سعيد", value: "+10k" },
            { label: "منتج طبيعي", value: "100%" },
            { label: "فرع حول العالم", value: "12" }
          ].map((stat, i) => (
            <div key={i} className="text-center space-y-0.5">
              <h4 className="text-2xl md:text-4xl font-headline font-black text-primary">{stat.value}</h4>
              <p className="text-[9px] text-on-surface-variant font-bold uppercase tracking-widest">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="space-y-8 max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end">
          <div className="space-y-2">
            <h2 className="text-2xl md:text-4xl font-headline font-black">عروض حصرية</h2>
            <p className="text-on-surface-variant text-sm">فرص لا تتكرر على أفضل منتجاتنا</p>
          </div>
          <button onClick={() => setView("products")} className="px-5 py-2.5 bg-primary/10 text-primary rounded-full font-black text-xs flex items-center gap-2 hover:bg-primary hover:text-on-primary transition-all">
            عرض الكل <ArrowLeft size={16} />
          </button>
        </div>
        <Carousel items={offers} onSelect={(p: any) => { setSelectedProduct(p); setView("product-detail"); }} addToCart={addToCart} setFullScreenImage={setFullScreenImage} currency={currency} formatPrice={formatPrice} />
      </section>

      {/* Storytelling Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 -skew-y-3" />
        <div className="max-w-7xl mx-auto px-4 relative z-10 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <span className="text-primary font-black tracking-[0.3em] uppercase text-sm">قصتنا</span>
            <h2 className="text-5xl md:text-7xl font-headline font-black leading-tight">
              من قلب الوديان <br/>
              <span className="text-primary italic">إلى مائدتكم</span>
            </h2>
            <p className="text-on-surface-variant text-xl leading-relaxed">
              بدأت رحلة الشهابي منذ أكثر من خمسين عاماً، حيث كان هدفنا دائماً هو الحفاظ على نقاء العسل الحضرمي وتقديمه للعالم بأعلى معايير الجودة. نحن لا نبيع العسل فحسب، بل ننقل لكم إرثاً من الصحة والعافية.
            </p>
            <div className="flex items-center gap-6">
              <div className="flex -space-x-4 rtl:space-x-reverse">
                {[1, 2, 3, 4].map(i => (
                  <img key={i} src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`} className="w-12 h-12 rounded-full border-4 border-background bg-surface" alt="" />
                ))}
              </div>
              <p className="text-sm font-bold text-on-surface-variant">انضم إلى أكثر من <span className="text-primary">10,000</span> عميل يثقون بنا</p>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 rounded-[60px] blur-3xl" />
            <motion.img 
              animate={{ 
                y: [0, -20, 0],
                rotate: [0, 2, 0, -2, 0]
              }}
              transition={{ 
                duration: 6, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
              src="https://images.unsplash.com/photo-1555939594-58d7cb561ad1?q=80&w=1000&auto=format&fit=crop" 
              className="relative w-full aspect-square object-cover rounded-[60px] luxury-shadow" 
              alt="Honey Story" 
            />
          </div>
        </div>
      </section>

      <section id="benefits" className="max-w-7xl mx-auto px-4 space-y-16">
        <div className="text-center space-y-4">
          <h2 className="text-4xl md:text-6xl font-headline font-black">لماذا عسل الشهابي؟</h2>
          <p className="text-on-surface-variant text-lg">نحن نلتزم بأعلى معايير الجودة في كل مرحلة</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: "نقاء 100%", desc: "عسل طبيعي خام غير مبستر وغير معالج حرارياً للحفاظ على كافة خصائصه العلاجية.", icon: "💎" },
            { title: "فحص مخبري", desc: "يخضع كل إنتاجنا لفحوصات مخبرية دقيقة لضمان خلوه من السكريات المضافة والمواد الكيميائية.", icon: "🔬" },
            { title: "تغليف فاخر", desc: "نستخدم عبوات زجاجية معتمة مصممة خصيصاً لحماية العسل من الضوء والحفاظ على جودته.", icon: "📦" }
          ].map((item, idx) => (
            <motion.div 
              key={idx} 
              whileHover={{ y: -10 }}
              className="p-10 bg-surface-container-low rounded-[40px] border border-white/5 luxury-shadow space-y-6 text-center"
            >
              <div className="text-6xl">{item.icon}</div>
              <h4 className="text-2xl font-headline font-black">{item.title}</h4>
              <p className="text-on-surface-variant leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 space-y-12">
        <div className="text-center space-y-4">
          <h2 className="text-4xl md:text-6xl font-headline font-black">الأكثر مبيعاً</h2>
          <p className="text-on-surface-variant text-lg">المنتجات التي نالت ثقة وإعجاب عملائنا</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
          {featured.map((product: Product) => (
            <ProductCard 
              key={product.id} 
              product={product} 
              addToCart={addToCart} 
              toggleFavorite={toggleFavorite} 
              isFavorite={favorites.includes(product.id)} 
              setView={setView} 
              setSelectedProduct={setSelectedProduct} 
              setFullScreenImage={setFullScreenImage}
              currency={currency}
              formatPrice={formatPrice}
            />
          ))}
        </div>
        <div className="text-center pt-8">
          <button 
            onClick={() => setView("products")}
            className="px-16 py-6 bg-primary text-on-primary rounded-full font-black text-xl shadow-2xl shadow-primary/40 hover:scale-105 active:scale-95 transition-all"
          >
            استكشف المتجر بالكامل
          </button>
        </div>
      </section>

      {/* Customer Reviews Section */}
      <section className="bg-surface-container-highest py-24 -mx-4 px-4">
        <div className="max-w-7xl mx-auto space-y-16">
          <div className="text-center space-y-4">
            <h2 className="text-4xl md:text-6xl font-headline font-black">قالوا عنا</h2>
            <p className="text-on-surface-variant text-lg">ثقة عملائنا هي سر نجاحنا واستمرارنا</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.slice(0, 3).map((review, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ scale: 1.02 }}
                className="bg-background p-10 rounded-[40px] luxury-shadow space-y-6 relative"
              >
                <div className="text-primary text-6xl absolute top-6 left-10 opacity-10 font-serif">"</div>
                <div className="flex items-center gap-4">
                  <img src={review.avatar} alt={review.name} className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/20" loading="lazy" />
                  <div>
                    <h4 className="font-headline font-bold text-xl">{review.name}</h4>
                    <div className="flex text-primary">
                      {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                    </div>
                  </div>
                </div>
                <p className="text-on-surface-variant italic leading-relaxed text-lg">"{review.text}"</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4">
        <div className="bg-surface-container-low rounded-[40px] p-8 md:p-12 border border-white/5 luxury-shadow space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            <div className="md:col-span-2 space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20">
                  <Logo />
                </div>
                <h3 className="text-2xl font-headline font-black text-primary">الشهابي للعسل</h3>
              </div>
              <p className="text-on-surface-variant text-base leading-relaxed max-w-md">
                نحن في متجر الشهابي نفخر بتقديم أجود أنواع العسل الحضرمي الأصيل، المستخلص بعناية من قلب الطبيعة اليمنية لنضمن لكم الجودة والنقاء.
              </p>
              <div className="flex gap-4">
                <button onClick={() => window.open("https://instagram.com", "_blank")} className="w-10 h-10 bg-background rounded-xl flex items-center justify-center text-primary hover:bg-primary hover:text-on-primary transition-all border border-white/10 shadow-lg">
                  <Instagram size={18} />
                </button>
                <button onClick={() => window.open("https://facebook.com", "_blank")} className="w-10 h-10 bg-background rounded-xl flex items-center justify-center text-primary hover:bg-primary hover:text-on-primary transition-all border border-white/10 shadow-lg">
                  <Facebook size={18} />
                </button>
                <button onClick={() => window.open("https://wa.me/967774586524", "_blank")} className="w-10 h-10 bg-background rounded-xl flex items-center justify-center text-primary hover:bg-primary hover:text-on-primary transition-all border border-white/10 shadow-lg">
                  <WhatsAppIcon size={18} />
                </button>
              </div>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-headline font-black border-r-4 border-primary pr-3">روابط سريعة</h4>
              <ul className="space-y-3 text-on-surface-variant font-bold text-xs">
                {[
                  { label: "الرئيسية", view: "home" },
                  { label: "المنتجات", view: "products" },
                  { label: "تواصل معنا", view: "contact" },
                  { label: "المفضلة", view: "favorites" },
                  { label: "السلة", view: "cart" }
                ].map((link, i) => (
                  <li key={i} onClick={() => setView(link.view as any)} className="hover:text-primary cursor-pointer transition-colors flex items-center gap-2">
                    <div className="w-1.5 h-1.5 bg-primary/30 rounded-full" />
                    {link.label}
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-6">
              <h4 className="text-lg font-headline font-black border-r-4 border-primary pr-3">تواصل معنا</h4>
              <ul className="space-y-4 text-on-surface-variant">
                <li className="flex items-center gap-3 cursor-pointer group" onClick={() => window.open("tel:+967774586524")}>
                  <div className="w-10 h-10 bg-background rounded-xl flex items-center justify-center text-primary border border-white/10 group-hover:bg-primary group-hover:text-on-primary transition-all"><Phone size={16} /></div>
                  <div>
                    <p className="text-[8px] uppercase font-black opacity-50 tracking-widest">رقم الهاتف</p>
                    <p className="font-black text-base">+967 774 586 524</p>
                  </div>
                </li>
                <li className="flex items-center gap-3 cursor-pointer group" onClick={() => window.open("mailto:info@alshahabi.com")}>
                  <div className="w-10 h-10 bg-background rounded-xl flex items-center justify-center text-primary border border-white/10 group-hover:bg-primary group-hover:text-on-primary transition-all"><Send size={16} /></div>
                  <div>
                    <p className="text-[8px] uppercase font-black opacity-50 tracking-widest">البريد الإلكتروني</p>
                    <p className="font-black text-base">info@alshahabi.com</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

          <div className="h-px bg-white/5" />

          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-sm text-on-surface-variant font-medium">© 2024 الشهابي للعسل الحضرمي. جميع الحقوق محفوظة.</p>
            <div className="flex items-center gap-6">
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png" className="h-5 grayscale opacity-30 hover:opacity-100 transition-opacity" alt="Visa" />
              <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/1280px-Mastercard-logo.svg.png" className="h-8 grayscale opacity-30 hover:opacity-100 transition-opacity" alt="Mastercard" />
            </div>
          </div>
        </div>
      </footer>
    </motion.div>
  );
}

function ProductsView({ products, addToCart, toggleFavorite, favorites, setView, setSelectedProduct, setFullScreenImage, currency, formatPrice }: any) {
  const [category, setCategory] = useState("الكل");
  const [sortBy, setSortBy] = useState("default");
  const [searchQuery, setSearchQuery] = useState("");

  const categories = ["الكل", ...Array.from(new Set(products.map((p: Product) => p.category)))];

  const filtered = products
    .filter((p: Product) => p.active)
    .filter((p: Product) => category === "الكل" || p.category === category)
    .filter((p: Product) => p.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a: Product, b: Product) => {
      if (sortBy === "price-low") return a.price - b.price;
      if (sortBy === "price-high") return b.price - a.price;
      return 0;
    });

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      className="space-y-8 pb-20"
    >
      <div className="sticky top-16 z-30 bg-background/95 backdrop-blur-2xl py-4 -mx-4 px-4 border-b border-white/5 shadow-sm">
        <div className="max-w-7xl mx-auto space-y-4">
          {/* Search and Filter Bar */}
          <div className="flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-primary" size={18} />
              <input 
                type="text" 
                placeholder="ابحث عن منتجاتنا الطبيعية..." 
                className="w-full bg-surface-container-low border border-white/10 rounded-2xl py-3.5 pr-12 pl-4 outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all text-sm"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <select 
                value={sortBy}
                onChange={e => setSortBy(e.target.value)}
                className="flex-1 md:flex-none bg-surface-container-low border border-white/10 rounded-2xl px-6 py-3.5 text-xs font-bold outline-none focus:border-primary/50 cursor-pointer appearance-none text-center min-w-[150px]"
              >
                <option value="default">الترتيب الافتراضي</option>
                <option value="price-low">السعر: من الأقل</option>
                <option value="price-high">السعر: من الأعلى</option>
              </select>
            </div>
          </div>

          {/* Categories Chips */}
          <div className="flex gap-2 overflow-x-auto hide-scrollbar pb-1">
            {categories.map((cat: any) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-6 py-2.5 rounded-xl text-[11px] font-black whitespace-nowrap transition-all duration-300 ${category === cat ? "bg-primary text-on-primary shadow-lg shadow-primary/25 scale-105" : "bg-surface-container-low text-on-surface-variant hover:bg-white/5 border border-white/5"}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4">
        {filtered.length > 0 ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
            <AnimatePresence mode="popLayout">
              {filtered.map((product: Product) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  addToCart={addToCart} 
                  toggleFavorite={toggleFavorite} 
                  isFavorite={favorites.includes(product.id)} 
                  setView={setView} 
                  setSelectedProduct={setSelectedProduct} 
                  setFullScreenImage={setFullScreenImage}
                  currency={currency}
                  formatPrice={formatPrice}
                />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <div className="text-center py-40 space-y-6">
            <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto text-primary">
              <Search size={48} />
            </div>
            <h3 className="text-2xl font-bold">لم نجد أي منتجات تطابق بحثك</h3>
            <button onClick={() => { setCategory("الكل"); setSearchQuery(""); }} className="text-primary font-bold underline">إعادة ضبط الفلاتر</button>
          </div>
        )}
      </div>
    </motion.div>
  );
}





function ProductDetailView({ product, products, addToCart, setView, toggleFavorite, isFavorite, favorites, setFullScreenImage, showMessage, currency, formatPrice, setSelectedProduct }: any) {
  const basePrice = product.price;
  const dynamicSizes = [
    { label: "ربع كيلو", price: Math.round(basePrice * 0.25) },
    { label: "نص كيلو", price: Math.round(basePrice * 0.5) },
    { label: "كيلو", price: basePrice },
    { label: "نص دبة 3.5 كيلو", price: Math.round(basePrice * 3.5) },
    { label: "دبة كامل 7 كيلو", price: Math.round(basePrice * 7) }
  ];

  const [selectedSize, setSelectedSize] = useState(dynamicSizes[2]); // Default to 1kg
  const [quantity, setQuantity] = useState(1);
  const [activeImg, setActiveImg] = useState(product.image);
  const allImages = [product.image, ...(product.images || [])].slice(0, 5);

  // Update selected size if product changes
  useEffect(() => {
    setSelectedSize(dynamicSizes[2]);
    setQuantity(1);
    setActiveImg(product.image);
    window.scrollTo(0, 0);
  }, [product]);

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedSize);
    if (product.fromCart) {
      setView("cart");
      showMessage("تم تحديث المنتج في السلة", "success");
    } else {
      showMessage("تمت الإضافة إلى السلة", "success");
    }
  };

  const handleDownloadCertificate = () => {
    if (!product.certificateImage) return;
    const link = document.createElement('a');
    link.href = product.certificateImage;
    link.download = `certificate-${product.name}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedSize);
    setView("checkout");
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: product.description,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      // @ts-ignore
      window.showMessage("تم نسخ الرابط للمشاركة", "success");
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }} 
      animate={{ opacity: 1, x: 0 }} 
      exit={{ opacity: 0, x: -20 }}
      className="space-y-12 pb-20"
    >
      <div className="flex justify-between items-center pt-4">
        <button onClick={() => setView(product.fromCart ? "cart" : "products")} className="flex items-center gap-2 text-primary font-black hover:scale-105 transition-transform bg-primary/10 px-4 py-2 rounded-xl text-xs">
          <ChevronRight size={16} /> {product.fromCart ? "العودة للسلة" : "العودة للمتجر"}
        </button>
        <div className="flex gap-2">
          <button onClick={handleShare} className="w-9 h-9 bg-surface-container-low rounded-xl flex items-center justify-center text-primary border border-white/5 hover:bg-primary/10 transition-all">
            <Share2 size={16} />
          </button>
          <button 
            onClick={() => toggleFavorite(product.id)}
            className={`w-9 h-9 rounded-xl flex items-center justify-center border border-white/5 transition-all ${isFavorite ? "bg-red-500 text-white shadow-lg shadow-red-500/30" : "bg-surface-container-low text-primary hover:bg-primary/10"}`}
          >
            <Heart size={16} fill={isFavorite ? "currentColor" : "none"} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Image Gallery */}
        <div className="space-y-3">
          <div 
            onClick={() => setFullScreenImage(activeImg)}
            className="relative aspect-[4/5] rounded-[24px] overflow-hidden border border-white/5 bg-surface-container-low luxury-shadow group cursor-zoom-in"
          >
            <motion.img 
              key={activeImg}
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              src={activeImg} 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
              alt={product.name} 
              loading="lazy"
            />
            <div className="absolute top-4 right-4 flex flex-col gap-1.5">
              {product.badge && <span className="glass text-white text-[8px] font-black px-2.5 py-1 rounded-full shadow-xl uppercase tracking-widest">{product.badge}</span>}
              {product.isDiscounted && <span className="bg-red-500 text-white text-[8px] font-black px-2.5 py-1 rounded-full shadow-xl uppercase tracking-widest">خصم {product.discountPercentage}%</span>}
            </div>
          </div>
          <div className="flex gap-2.5 overflow-x-auto hide-scrollbar py-1 px-0.5">
            {allImages.map((img: string, i: number) => (
              <button 
                key={i} 
                onClick={() => setActiveImg(img)}
                className={`flex-none w-16 h-16 rounded-[16px] overflow-hidden border-2 transition-all duration-500 ${activeImg === img ? "border-primary scale-105 shadow-2xl shadow-primary/30" : "border-transparent opacity-40 hover:opacity-100"}`}
              >
                <img src={img} className="w-full h-full object-cover" alt="" loading="lazy" />
              </button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="space-y-6">
          <div className="space-y-2">
            <span className="text-primary font-black tracking-[0.3em] uppercase text-[9px]">{product.category}</span>
            <h2 className="text-3xl md:text-4xl font-headline font-black text-on-surface leading-tight">{product.name}</h2>
            <div className="flex items-center gap-2.5 text-on-surface-variant">
              <div className="flex text-primary">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
              </div>
              <span className="text-[10px] font-bold">(120 تقييم إيجابي)</span>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-headline font-black text-base">اختر الحجم</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5">
              {dynamicSizes.map((size, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedSize(size)}
                  className={`p-2.5 rounded-[16px] border-2 transition-all duration-300 text-right space-y-0.5 ${selectedSize.label === size.label ? "border-primary bg-primary/5 shadow-lg shadow-primary/10" : "border-white/5 bg-surface-container-low hover:border-primary/30"}`}
                >
                  <p className="text-[9px] font-bold opacity-60">{size.label}</p>
                  <p className="text-sm font-black text-primary">{formatPrice(size.price)} {currency.symbol}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-5 py-3 border-y border-white/5">
            <div className="space-y-1">
              <p className="text-[9px] font-black text-on-surface-variant uppercase tracking-widest">الكمية</p>
              <div className="flex items-center bg-surface-container-low rounded-lg border border-white/5 p-0.5">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-7 h-7 flex items-center justify-center hover:bg-white/5 rounded-md transition-colors"><Minus size={12} /></button>
                <span className="w-8 text-center font-black text-sm">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)} className="w-7 h-7 flex items-center justify-center hover:bg-white/5 rounded-md transition-colors"><Plus size={12} /></button>
              </div>
            </div>
            <div className="flex-1 space-y-0.5">
              <p className="text-[9px] font-black text-on-surface-variant uppercase tracking-widest">الإجمالي</p>
              <p className="text-2xl font-headline font-black text-primary">{formatPrice(selectedSize.price * quantity)} {currency.symbol}</p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-2.5">
            <button 
              onClick={handleAddToCart}
              className="flex-1 px-6 py-3 bg-primary text-on-primary rounded-[16px] font-black text-base shadow-2xl shadow-primary/40 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <ShoppingBag size={18} /> {product.fromCart ? "تعديل في السلة" : "إضافة للسلة"}
            </button>
            <button 
              onClick={handleBuyNow}
              className="flex-1 px-6 py-3 bg-white/5 text-on-surface border border-white/10 rounded-[16px] font-black text-base hover:bg-white/10 transition-all"
            >
              شراء الآن
            </button>
          </div>

          {product.certificateImage && (
            <button 
              onClick={handleDownloadCertificate}
              className="w-full p-4 bg-green-600/10 text-green-600 rounded-[20px] border border-green-600/20 font-black flex items-center justify-center gap-2.5 hover:bg-green-600/20 transition-all text-sm"
            >
              <Download size={18} /> تحميل شهادة الجودة والمنشأ
            </button>
          )}

          <div className="space-y-3 pt-4">
            <h4 className="font-headline font-black text-lg">وصف المنتج</h4>
            <p className="text-on-surface-variant leading-relaxed text-base">
              {product.description}
            </p>
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="space-y-12 pt-12 border-t border-white/5">
        <h3 className="text-3xl md:text-5xl font-headline font-black">منتجات قد تعجبك</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 md:gap-10">
          {products.filter((p: Product) => p.category === product.category && p.id !== product.id).slice(0, 4).map((p: Product) => (
            <ProductCard 
              key={p.id} 
              product={p} 
              addToCart={addToCart} 
              toggleFavorite={toggleFavorite} 
              isFavorite={favorites.includes(p.id)} 
              setView={setView} 
              setSelectedProduct={setSelectedProduct} 
              setFullScreenImage={setFullScreenImage}
              currency={currency}
              formatPrice={formatPrice}
            />
          ))}
        </div>
      </section>
    </motion.div>
  );
}

function CartView({ cart, updateQuantity, removeFromCart, total, setView, currency, formatPrice, setSelectedProduct }: any) {
  if (cart.length === 0) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-20 space-y-6">
        <div className="w-24 h-24 bg-surface-container-high rounded-full flex items-center justify-center mx-auto text-on-surface/20">
          <ShoppingBag size={48} />
        </div>
        <h2 className="text-2xl font-bold">السلة فارغة</h2>
        <p className="text-on-surface-variant">لم تقم بإضافة أي منتجات بعد.</p>
        <button onClick={() => setView("products")} className="bg-primary text-on-primary px-8 py-3 rounded-full font-bold">تسوق الآن</button>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8 pb-10">
      <h2 className="text-3xl font-headline font-bold text-center">سلة التسوق</h2>
      
      <div className="space-y-4">
        {cart.map((item: CartItem) => (
          <div 
            key={`${item.id}-${item.selectedSize}`} 
            className="bg-surface-container-low p-4 rounded-[30px] flex items-center gap-4 border border-amber-900/10 dark:border-white/5 cursor-pointer hover:bg-surface-container-high transition-colors"
            onClick={() => {
              setSelectedProduct({ ...item, fromCart: true });
              setView("product-detail");
            }}
          >
            <img src={item.image} className="w-20 h-20 rounded-2xl object-cover" alt={item.name} />
            <div className="flex-1">
              <h4 className="font-bold text-sm">{item.name}</h4>
              {item.selectedSize && <p className="text-[10px] text-on-surface-variant">الحجم: {item.selectedSize}</p>}
              <p className="text-primary font-bold text-sm">{formatPrice(item.finalPrice)} {currency.symbol}</p>
              <div className="flex items-center gap-3 mt-2" onClick={e => e.stopPropagation()}>
                <button onClick={() => updateQuantity(item.id, item.selectedSize, -1)} className="w-8 h-8 bg-surface-container-high rounded-full flex items-center justify-center text-on-surface"><Minus size={14} /></button>
                <span className="font-bold">{item.quantity}</span>
                <button onClick={() => updateQuantity(item.id, item.selectedSize, 1)} className="w-8 h-8 bg-surface-container-high rounded-full flex items-center justify-center text-on-surface"><Plus size={14} /></button>
              </div>
            </div>
            <button 
              onClick={(e) => { e.stopPropagation(); removeFromCart(item.id, item.selectedSize); }} 
              className="text-error/60 hover:text-error transition-colors p-2"
            >
              <Trash2 size={20} />
            </button>
          </div>
        ))}
      </div>

      <div className="bg-surface-container-high p-8 rounded-[40px] space-y-6 border border-amber-900/10 dark:border-white/5">
        <div className="flex justify-between items-center">
          <span className="text-on-surface-variant">الإجمالي الفرعي:</span>
          <span className="font-bold">{formatPrice(total)} {currency.symbol}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-on-surface-variant">التوصيل:</span>
          <span className="text-primary font-bold">مجاني</span>
        </div>
        <div className="h-px bg-white/5" />
        <div className="flex justify-between items-center text-xl">
          <span className="font-bold">الإجمالي الكلي:</span>
          <span className="text-primary font-extrabold">{formatPrice(total)} {currency.symbol}</span>
        </div>
        <button onClick={() => setView("checkout")} className="w-full py-4 bg-primary text-on-primary rounded-full font-bold text-lg shadow-xl shadow-primary/30 active:scale-95 transition-all">
          إتمام الطلب
        </button>
      </div>
    </motion.div>
  );
}

function FavoritesView({ products, favorites, toggleFavorite, addToCart, setView, setSelectedProduct, setFullScreenImage, currency, formatPrice }: any) {
  const favProducts = products.filter((p: Product) => favorites.includes(p.id));

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 pb-10">
      <div className="text-center">
        <h2 className="text-3xl font-headline font-bold mb-2">المفضلة</h2>
        <p className="text-on-surface-variant text-sm">لقد حفظت {favProducts.length} قطع استثنائية من كنوز العسل اليمني.</p>
      </div>

      {favProducts.length === 0 ? (
        <div className="text-center py-20 text-on-surface-variant">لا توجد منتجات في المفضلة.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {favProducts.map((product: Product) => (
            <ProductCard key={product.id} product={product} addToCart={addToCart} toggleFavorite={toggleFavorite} isFavorite={true} setView={setView} setSelectedProduct={setSelectedProduct} setFullScreenImage={setFullScreenImage} currency={currency} formatPrice={formatPrice} />
          ))}
        </div>
      )}
    </motion.div>
  );
}

function ContactView() {
  const contacts = [
    { icon: <WhatsAppIcon className="text-green-500" />, label: "واتساب", sub: "تواصل سريع ومباشر", link: "https://wa.me/967774586524" },
    { icon: <Phone className="text-blue-500" />, label: "اتصال هاتفي", sub: "متاحون من 9 صباحاً إلى 9 مساءً", link: "tel:+967774586524" },
    { icon: <Instagram className="text-pink-500" />, label: "انستقرام", sub: "تابعوا رحلة حصادنا اليومية", link: "#" },
    { icon: <Facebook className="text-blue-600" />, label: "فيسبوك", sub: "مجتمع عشاق العسل الأصلي", link: "#" },
  ];

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8 pb-10 text-center">
      <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
        <Headset size={48} className="text-primary" />
      </div>
      <h2 className="text-3xl font-headline font-bold">نسعد بخدمتكم</h2>
      <p className="text-on-surface-variant max-w-sm mx-auto">فريق آل شهابي جاهز للرد على استفساراتكم حول أجود أنواع العسل اليمني الأصيل.</p>

      <div className="grid grid-cols-1 gap-4 mt-10">
        <StoreOwnerCard isContactPage={true} />
        <DeveloperCard isContactPage={true} />
        {contacts.map((c, i) => (
          <motion.a 
            key={i}
            href={c.link}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-surface-container-low p-6 rounded-[30px] flex items-center gap-6 border border-amber-900/10 dark:border-white/5 hover:bg-surface-container-high transition-colors group"
          >
            <div className="w-14 h-14 bg-background rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
              {c.icon}
            </div>
            <div className="text-right">
              <h4 className="font-bold text-lg">{c.label}</h4>
              <p className="text-xs text-on-surface-variant">{c.sub}</p>
            </div>
            <ArrowLeft className="mr-auto text-on-surface/20 group-hover:text-primary transition-colors" size={20} />
          </motion.a>
        ))}
      </div>

      <div className="mt-12 p-8 bg-surface-container-high rounded-[40px] border border-white/5">
        <h4 className="font-bold text-primary mb-4">المقر الرئيسي</h4>
        <p className="text-sm text-on-surface-variant mb-6">تفضل بزيارتنا لتذوق أصنافنا المتنوعة من العسل في قلب اليمن، حيث تلتقي التقاليد بالجودة العالية.</p>
        <div className="flex items-center justify-center gap-2 text-on-surface font-bold">
          <span className="material-symbols-outlined text-primary">location_on</span>
          صنعاء، حي حدة
        </div>
      </div>
    </motion.div>
  );
}

function CheckoutView({ total, onConfirm, cart, currency, formatPrice }: any) {
  const [formData, setFormData] = useState<OrderDetails>({
    name: "",
    phone: "",
    country: "اليمن",
    governorate: "صنعاء",
    city: "",
    address: "",
    notes: "",
    paymentMethod: "الدفع عند الاستلام",
    locationUrl: localStorage.getItem("lastLocation") || ""
  });

  const [locationStatus, setLocationStatus] = useState<"idle" | "loading" | "success" | "error">("idle");

  const yemeniGovernorates = [
    "صنعاء", "عدن", "تعز", "حضرموت", "الحديدة", "إب", "أبين", "البيضاء", "الجوف", "المهرة", "المحويت", "الضالع", "ذمار", "حجة", "لحج", "مأرب", "ريمة", "شبوة", "سقطرى", "صعدة", "عمران"
  ];

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      // @ts-ignore
      window.showMessage("متصفحك لا يدعم تحديد الموقع", "error");
      return;
    }

    setLocationStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const url = `https://www.google.com/maps?q=${latitude},${longitude}`;
        setFormData(prev => ({ ...prev, locationUrl: url, address: prev.address || "تم تحديد الموقع تلقائياً" }));
        setLocationStatus("success");
        localStorage.setItem("lastLocation", url);
        // @ts-ignore
        window.showMessage("تم تحديد موقعك بنجاح ", "success");
      },
      (error) => {
        console.error(error);
        setLocationStatus("error");
        // @ts-ignore
        window.showMessage("فشل تحديد الموقع، يرجى السماح بالإذن أو إدخال العنوان يدوياً", "error");
      }
    );
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone || !formData.address || !formData.city) {
      // @ts-ignore
      window.showMessage("يرجى ملء جميع الحقول المطلوبة", "error");
      return;
    }
    onConfirm(formData);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8 pb-10">
      <h2 className="text-3xl font-headline font-bold text-center">إتمام الطلب</h2>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-4">
          <h3 className="font-bold flex items-center gap-2"><span className="w-6 h-6 bg-primary text-on-primary rounded-full flex items-center justify-center text-[10px]">1</span> معلومات الشحن</h3>
          <div className="space-y-4 bg-surface-container-low p-6 rounded-[30px] border border-amber-900/10 dark:border-white/5">
            <input 
              type="text" placeholder="الاسم الكامل" required
              className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
              value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})}
            />
            <input 
              type="tel" placeholder="رقم الهاتف" required
              className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
              value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})}
            />
            
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-on-surface-variant px-2 uppercase">الدولة</label>
                <select 
                  className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
                  value={formData.country} onChange={e => setFormData({...formData, country: e.target.value, governorate: e.target.value === "اليمن" ? "صنعاء" : ""})}
                >
                  <option value="اليمن">اليمن</option>
                  <option value="السعودية">السعودية</option>
                </select>
              </div>
              
              {formData.country === "اليمن" && (
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-on-surface-variant px-2 uppercase">المحافظة</label>
                  <select 
                    className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
                    value={formData.governorate} onChange={e => setFormData({...formData, governorate: e.target.value})}
                  >
                    {yemeniGovernorates.map(gov => <option key={gov} value={gov}>{gov}</option>)}
                  </select>
                </div>
              )}
            </div>

            <input 
              type="text" placeholder={formData.country === "اليمن" ? "المديرية / المنطقة" : "المدينة"} required
              className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
              value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})}
            />

            <div className="space-y-3">
              <button 
                type="button"
                onClick={handleGetLocation}
                disabled={locationStatus === "loading"}
                className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all border-2 ${
                  locationStatus === "success" ? "bg-green-500/10 border-green-500 text-green-500" : 
                  locationStatus === "loading" ? "bg-primary/10 border-primary text-primary animate-pulse" :
                  "bg-primary/5 border-primary/20 text-primary hover:bg-primary/10"
                }`}
              >
                <MapPin size={20} />
                {locationStatus === "loading" ? "جاري تحديد موقعك..." : 
                 locationStatus === "success" ? "تم تحديد موقعك بنجاح " : 
                 " تحديد موقعي تلقائياً"}
              </button>
              
              <input 
                type="text" placeholder="العنوان بالتفصيل (شارع، معلم بارز)" required
                className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 focus:outline-none focus:border-primary/50 transition-colors"
                value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})}
              />
              
              {formData.locationUrl && (
                <div className="p-3 bg-primary/5 rounded-xl border border-primary/10 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-primary truncate max-w-[200px]">{formData.locationUrl}</span>
                  <button type="button" onClick={() => setFormData({...formData, locationUrl: ""})} className="text-error p-1"><X size={14} /></button>
                </div>
              )}
            </div>

            <textarea 
              placeholder="ملاحظات إضافية (اختياري)"
              className="w-full bg-background border border-amber-900/10 dark:border-white/5 rounded-2xl p-4 h-32 focus:outline-none focus:border-primary/50 transition-colors"
              value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})}
            />
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="font-bold flex items-center gap-2"><span className="w-6 h-6 bg-primary text-on-primary rounded-full flex items-center justify-center text-[10px]">2</span> طريقة الدفع</h3>
          <div className="grid grid-cols-1 gap-3">
            {["الدفع عند الاستلام", "محفظة إلكترونية", "تحويل بنكي"].map(method => (
              <label key={method} className={`p-5 rounded-3xl border transition-all cursor-pointer flex items-center justify-between ${formData.paymentMethod === method ? "border-primary bg-primary/5" : "border-amber-900/10 dark:border-white/5 bg-surface-container-low"}`}>
                <div className="flex items-center gap-4">
                  <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${formData.paymentMethod === method ? "border-primary" : "border-on-surface/20"}`}>
                    {formData.paymentMethod === method && <div className="w-2.5 h-2.5 bg-primary rounded-full" />}
                  </div>
                  <span className="font-bold">{method}</span>
                </div>
                <input type="radio" name="payment" className="hidden" value={method} checked={formData.paymentMethod === method} onChange={() => setFormData({...formData, paymentMethod: method})} />
              </label>
            ))}
          </div>
        </div>

        <div className="bg-surface-container-high p-8 rounded-[40px] space-y-6 border border-amber-900/10 dark:border-white/5">
          <div className="space-y-2">
            {cart.map((item: CartItem) => (
              <div key={`${item.id}-${item.selectedSize}`} className="flex justify-between text-sm">
                <span className="text-on-surface-variant">{item.name} {item.selectedSize ? `(${item.selectedSize})` : ""} ({item.quantity}x)</span>
                <span>{item.finalPrice * item.quantity} ر.ي</span>
              </div>
            ))}
          </div>
          <div className="h-px bg-white/5" />
          <div className="flex justify-between items-center text-xl">
            <span className="font-bold">الإجمالي الكلي:</span>
            <span className="text-primary font-extrabold">{total} <span className="text-sm">ر.ي</span></span>
          </div>
          <button type="submit" className="w-full py-4 bg-primary text-on-primary rounded-full font-bold text-lg shadow-xl shadow-primary/30 active:scale-95 transition-all">
            عرض الفاتورة
          </button>
        </div>
      </form>
    </motion.div>
  );
}

function InvoiceView({ orderDetails, cart, total, onSend, currency, formatPrice, setView, orderId }: any) {
  const invoiceRef = useRef<HTMLDivElement>(null);
  const date = new Date().toLocaleDateString("ar-YE", { year: 'numeric', month: 'long', day: 'numeric' });

  const downloadAsImage = async () => {
    if (!invoiceRef.current) return;
    // @ts-ignore
    window.showMessage("جاري تجهيز الصورة الإبداعية...", "info");
    try {
      const canvas = await htmlToImage.toCanvas(invoiceRef.current, {
        pixelRatio: 4,
        backgroundColor: "#ffffff",
        style: {
          borderRadius: "0",
          boxShadow: "none",
          padding: "40px",
        }
      });
      
      // Create a nice background for the "creative" image
      const creativeCanvas = document.createElement('canvas');
      const ctx = creativeCanvas.getContext('2d');
      if (!ctx) return;
      
      creativeCanvas.width = canvas.width + 200;
      creativeCanvas.height = canvas.height + 200;
      
      // Draw a nice gradient background
      const grad = ctx.createLinearGradient(0, 0, creativeCanvas.width, creativeCanvas.height);
      grad.addColorStop(0, '#d4af37');
      grad.addColorStop(1, '#2d1e12');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, creativeCanvas.width, creativeCanvas.height);
      
      // Draw the invoice in the center with a shadow
      ctx.shadowColor = 'rgba(0,0,0,0.5)';
      ctx.shadowBlur = 50;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 20;
      ctx.drawImage(canvas, 100, 100);
      
      const link = document.createElement('a');
      link.download = `alshahabi-creative-invoice-${orderId}.png`;
      link.href = creativeCanvas.toDataURL("image/png");
      link.click();
      // @ts-ignore
      window.showMessage("تم تحميل الفاتورة كصورة إبداعية بنجاح", "success");
    } catch (err) {
      console.error("Image generation failed:", err);
      // @ts-ignore
      window.showMessage("فشل تحميل الفاتورة", "error");
    }
  };

  return (
    <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="space-y-8 pb-10">
      <div ref={invoiceRef} className="bg-surface-container-high rounded-[50px] p-8 border border-white/10 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-primary" />
        
        <div className="text-center mb-10">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 size={40} className="text-primary" />
          </div>
          <h2 className="text-3xl font-headline font-extrabold mb-2">الفاتورة الضريبية</h2>
          <p className="text-on-surface-variant text-sm">رقم الطلب: #{orderId}</p>
          <p className="text-on-surface-variant text-xs mt-1">التاريخ: {date}</p>
        </div>

        <div className="space-y-8">
          <div className="bg-background/50 p-6 rounded-[30px] border border-amber-900/10 dark:border-white/5">
            <h4 className="text-primary font-bold mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-sm">person</span> معلومات العميل</h4>
            <p className="font-bold text-lg">{orderDetails.name}</p>
            <p className="text-sm text-on-surface-variant">{orderDetails.phone}</p>
            <p className="text-sm text-on-surface-variant mt-2">{orderDetails.country} - {orderDetails.governorate || ""} - {orderDetails.city}</p>
            <p className="text-sm text-on-surface-variant">{orderDetails.address}</p>
            {orderDetails.locationUrl && (
              <a href={orderDetails.locationUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-primary text-xs font-bold mt-3 bg-primary/10 px-4 py-2 rounded-full">
                <MapPin size={14} /> عرض الموقع على الخريطة
              </a>
            )}
          </div>

          <div className="bg-background/50 p-6 rounded-[30px] border border-amber-900/10 dark:border-white/5">
            <h4 className="text-primary font-bold mb-4 flex items-center gap-2"><span className="material-symbols-outlined text-sm">payments</span> طريقة الدفع</h4>
            <div className="flex justify-between items-center">
              <span className="font-bold">{orderDetails.paymentMethod}</span>
              <span className="px-3 py-1 bg-yellow-500/10 text-yellow-500 text-[10px] font-bold rounded-full">بانتظار التأكيد</span>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-primary font-bold flex items-center gap-2"><span className="material-symbols-outlined text-sm">shopping_basket</span> تفاصيل المنتجات</h4>
            <div className="space-y-3">
              {cart.map((item: CartItem) => (
                <div key={`${item.id}-${item.selectedSize}`} className="flex justify-between items-center text-sm">
                  <div className="flex items-center gap-3">
                    <img src={item.image} className="w-12 h-12 rounded-xl object-cover" alt="" />
                    <div>
                      <p className="font-bold">{item.name}</p>
                      <p className="text-[10px] text-on-surface-variant">{item.selectedSize ? `الحجم: ${item.selectedSize} | ` : ""}{item.quantity} وحدة  {formatPrice(item.finalPrice)} {currency.symbol}</p>
                    </div>
                  </div>
                  <span className="font-bold">{formatPrice(item.finalPrice * item.quantity)} {currency.symbol}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="h-px bg-white/5" />

          <div className="space-y-3">
            <div className="flex justify-between text-sm text-on-surface-variant">
              <span>المجموع الفرعي:</span>
              <span>{formatPrice(total)} {currency.symbol}</span>
            </div>
            <div className="flex justify-between text-sm text-on-surface-variant">
              <span>رسوم التوصيل:</span>
              <span className="text-primary font-bold">مجاني</span>
            </div>
            <div className="flex justify-between items-center text-2xl font-extrabold pt-4">
              <span>الإجمالي النهائي:</span>
              <span className="text-primary">{formatPrice(total)} {currency.symbol}</span>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <p className="text-[10px] text-on-surface-variant italic">شكراً لاختياركم "الشهابي". عسلنا إرث نعتز بنقله إليكم.</p>
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <button onClick={onSend} className="w-full py-5 bg-[#25D366] text-white rounded-[24px] font-black text-xl shadow-2xl shadow-green-500/30 active:scale-95 transition-all flex items-center justify-center gap-4 group">
          <WhatsAppIcon size={28} className="group-hover:rotate-12 transition-transform" /> إرسال الطلب عبر واتساب
        </button>
        
        <button onClick={downloadAsImage} className="w-full py-5 bg-surface-container-high text-on-surface rounded-[24px] font-black text-lg border border-white/10 hover:bg-white/10 transition-all flex items-center justify-center gap-3">
          <Image size={22} className="text-secondary" /> تحميل الفاتورة
        </button>

        <button 
          onClick={() => setView("home")}
          className="w-full py-5 bg-white/5 text-on-surface rounded-[24px] font-black text-lg border border-white/10 hover:bg-white/10 transition-all flex items-center justify-center gap-3"
        >
          <Home size={22} className="text-primary" /> العودة للرئيسية
        </button>
      </div>
    </motion.div>
  );
}

function LivePreview({ url }: { url: string }) {
  const isImage = url.match(/\.(jpeg|jpg|gif|png|webp)$/) != null || url.startsWith("data:image");
  const isValidUrl = url.startsWith("http://") || url.startsWith("https://") || url.startsWith("data:image");

  if (!url) return null;
  if (!isValidUrl) return <p className="text-error text-[10px] mt-1">الرابط غير صالح، يرجى إدخال رابط صحيح</p>;

  return (
    <div className="mt-4 p-4 bg-background/50 rounded-2xl border border-white/10 shadow-inner">
      <p className="text-[10px] font-bold text-on-surface-variant mb-2 uppercase tracking-widest">معاينة حية</p>
      {isImage ? (
        <div className="relative group overflow-hidden rounded-xl border border-white/5">
          <img src={url} className="w-full max-h-48 object-contain transition-transform group-hover:scale-105" alt="Preview" />
        </div>
      ) : (
        <div className="aspect-video w-full rounded-xl overflow-hidden border border-white/5 bg-white">
          <iframe 
            src={url} 
            className="w-full h-full border-none" 
            title="Preview"
            sandbox="allow-scripts allow-same-origin"
          />
        </div>
      )}
    </div>
  );
}

// --- Account View ---
function AccountView({ currentUser, showMessage, setView, completedOrdersCount, setShowLogoutConfirm }: { currentUser: FirebaseUser | null, showMessage: any, setView: any, completedOrdersCount: number, setShowLogoutConfirm: any }) {
  const [showLoyalty, setShowLoyalty] = useState(false);
  const [phone, setPhone] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoginMode, setIsLoginMode] = useState(false);

  const handleGoogleLogin = async () => {
    try {
      const { googleProvider, signInWithPopup } = await import("./firebase");
      await signInWithPopup(auth, googleProvider);
      showMessage("تم تسجيل الدخول بنجاح", "success");
    } catch (error) {
      console.error("Login Error:", error);
      showMessage("فشل تسجيل الدخول", "error");
    }
  };

  const handleAuth = async (e: FormEvent) => {
    e.preventDefault();
    if (phone.length < 9) {
      showMessage("يرجى إدخال رقم هاتف صحيح", "error");
      return;
    }

    setIsLoading(true);
    try {
      const { signInAnonymously, updateProfile } = await import("firebase/auth");
      
      // Check if phone is already registered
      const mappingSnap = await getDoc(doc(db, "phone_to_uid", phone));
      
      if (isLoginMode) {
        if (!mappingSnap.exists()) {
          showMessage("رقم الهاتف غير مسجل. يرجى إنشاء حساب جديد.", "error");
          setIsLoading(false);
          return;
        }
        
        const userCredential = await signInAnonymously(auth);
        const user = userCredential.user;
        
        await updateProfile(user, {
          displayName: "عميل الشهابي",
        });
        
        // Link current UID to this phone
        await setDoc(doc(db, "users", user.uid), { phone, name: "عميل الشهابي", createdAt: new Date().toISOString() }, { merge: true });
        // Update mapping to latest UID (optional, but helps track)
        await setDoc(doc(db, "phone_to_uid", phone), { uid: user.uid }, { merge: true });
        
        showMessage("تم تسجيل الدخول بنجاح", "success");
      } else {
        if (mappingSnap.exists()) {
          showMessage("رقم الهاتف مسجل مسبقاً. يرجى تسجيل الدخول.", "info");
          setIsLoginMode(true);
          setIsLoading(false);
          return;
        }

        const userCredential = await signInAnonymously(auth);
        const user = userCredential.user;
        
        await updateProfile(user, {
          displayName: "عميل الشهابي",
        });

        await setDoc(doc(db, "users", user.uid), {
          uid: user.uid,
          name: "عميل الشهابي",
          phone: phone,
          createdAt: new Date().toISOString()
        }, { merge: true });
        
        await setDoc(doc(db, "phone_to_uid", phone), { uid: user.uid }, { merge: true });

        showMessage("تم إنشاء الحساب بنجاح", "success");
      }
    } catch (error) {
      console.error("Auth Error:", error);
      showMessage(isLoginMode ? "فشل تسجيل الدخول" : "فشل إنشاء الحساب", "error");
    } finally {
      setIsLoading(false);
    }
  };

  if (currentUser) {
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-md mx-auto py-10 space-y-8 text-center">
        <div className="relative inline-block">
          <img src={currentUser.photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(currentUser.displayName || "U")}&background=d4af37&color=fff`} className="w-24 h-24 rounded-full border-4 border-primary shadow-xl mx-auto" alt="" />
          <div className="absolute bottom-0 right-0 w-8 h-8 bg-success rounded-full border-4 border-background flex items-center justify-center">
            <CheckCircle2 size={14} className="text-white" />
          </div>
        </div>
        <div className="space-y-2">
          <h2 className="text-2xl font-bold">{currentUser.displayName || "عميل الشهابي"}</h2>
          <p className="text-on-surface-variant text-sm">{currentUser.email || currentUser.phoneNumber || "حساب هاتف"}</p>
        </div>
        
        <div className="grid grid-cols-1 gap-4">
          <button 
            onClick={() => setShowLoyalty(!showLoyalty)} 
            className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all ${showLoyalty ? "bg-primary text-on-primary shadow-lg shadow-primary/20" : "bg-surface-container-low border border-white/5 hover:bg-primary/10"}`}
          >
            <Star size={20} className={showLoyalty ? "text-on-primary" : "text-primary"} /> برنامج مكافآت النحل
          </button>

          <AnimatePresence>
            {showLoyalty && (
              <motion.div 
                initial={{ opacity: 0, height: 0 }} 
                animate={{ opacity: 1, height: "auto" }} 
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="relative overflow-hidden bg-gradient-to-br from-amber-900 via-amber-950 to-black rounded-[30px] p-8 text-white shadow-2xl border border-amber-500/30 group text-right">
                  <div className="absolute -top-20 -right-20 w-60 h-60 bg-primary/20 rounded-full blur-[80px]" />
                  
                  <div className="relative space-y-6">
                    <div className="inline-flex items-center gap-3 bg-primary/20 px-4 py-1.5 rounded-full border border-primary/40 backdrop-blur-md">
                      <Star size={16} className="text-primary fill-primary animate-pulse" />
                      <span className="text-xs font-black text-primary uppercase tracking-widest">مكافآت النحل</span>
                    </div>
                    
                    <h3 className="text-2xl font-headline font-black leading-tight">
                      اطلب <span className="text-primary underline underline-offset-4">3 مرات</span> <br/>
                      واحصل على <span className="text-secondary text-3xl">20% خصم</span>
                    </h3>
                    
                    <p className="text-white/60 text-sm leading-relaxed">كل طلب مكتمل يجعلك أقرب للخصم. نحن نقدر وفاءك الدائم لمنتجاتنا.</p>
                    
                    <div className="flex justify-center gap-3 py-2">
                      {[1, 2, 3].map((step) => (
                        <div key={step} className="relative">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-500 ${completedOrdersCount >= step ? "bg-primary text-on-primary scale-110 shadow-lg shadow-primary/30" : "bg-white/5 text-white/20 border border-white/10"}`}>
                            {completedOrdersCount >= step ? <CheckCircle2 size={24} /> : <span className="text-lg font-black">{step}</span>}
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="relative h-24 flex items-center justify-center">
                      <svg className="w-20 h-20 -rotate-90">
                        <circle cx="40" cy="40" r="35" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="6" />
                        <motion.circle 
                          cx="40" cy="40" r="35" fill="none" stroke="#d4af37" strokeWidth="6" 
                          strokeDasharray={220}
                          initial={{ strokeDashoffset: 220 }}
                          animate={{ strokeDashoffset: 220 - (Math.min(completedOrdersCount, 3) / 3) * 220 }}
                          transition={{ duration: 1.5 }}
                          strokeLinecap="round"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-2xl font-black text-primary">
                          {completedOrdersCount >= 3 ? "20%" : `${completedOrdersCount}/3`}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <button onClick={() => setView("orders")} className="w-full py-4 bg-surface-container-low border border-white/5 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-primary/10 transition-all">
            <History size={20} className="text-primary" /> سجل الطلبات
          </button>
          <button onClick={() => setShowLogoutConfirm(true)} className="w-full py-4 bg-error/10 text-error rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-error/20 transition-all">
            <X size={20} /> تسجيل الخروج
          </button>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md mx-auto py-10 space-y-8">
      <div className="text-center space-y-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.3 }}
              className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto shadow-inner relative"
            >
              <UserPlus size={48} className="text-primary" />
              <motion.div 
                animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 bg-primary/20 rounded-full"
              />
            </motion.div>
        <h2 className="text-4xl font-headline font-black">{isLoginMode ? "تسجيل الدخول" : "إنشاء حساب جديد"}</h2>
        <p className="text-on-surface-variant text-lg">{isLoginMode ? "مرحباً بك مجدداً في عالم الشهابي" : "انضم إلينا لحفظ طلباتك والحصول على نقاط النحل"}</p>
      </div>

      <div className="space-y-6">
        <button 
          onClick={handleGoogleLogin}
          className="w-full py-5 bg-white text-black border border-gray-200 rounded-[20px] font-bold flex items-center justify-center gap-3 shadow-xl hover:bg-gray-50 transition-all active:scale-95"
        >
          <img 
            src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
            className="w-6 h-6" 
            alt="Google Logo" 
            referrerPolicy="no-referrer"
          />
          {isLoginMode ? "الدخول عبر جوجل" : "التسجيل السريع عبر جوجل"}
        </button>

        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10"></div></div>
          <div className="relative flex justify-center text-xs uppercase"><span className="bg-background px-6 text-on-surface-variant font-bold tracking-widest">أو عبر رقم الهاتف</span></div>
        </div>

        <form onSubmit={handleAuth} className="space-y-4">
          <div className="space-y-4">
            <div className="relative">
              <input 
                type="tel" 
                placeholder="رقم الهاتف (7xxxxxxxx)" 
                className="w-full bg-surface-container-low border border-white/5 rounded-2xl p-5 pr-14 focus:border-primary/50 transition-all outline-none shadow-inner"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                required
              />
              <Phone className="absolute right-5 top-1/2 -translate-y-1/2 text-on-surface-variant" size={20} />
            </div>
          </div>
          
          <button 
            type="submit" 
            disabled={isLoading}
            className="w-full py-5 bg-primary text-on-primary rounded-[20px] font-black text-lg shadow-2xl shadow-primary/30 hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-3"
          >
            {isLoading ? <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : (isLoginMode ? "تسجيل الدخول" : "إنشاء الحساب الآن")}
          </button>
        </form>
        
        <div className="text-center">
          <button 
            onClick={() => setIsLoginMode(!isLoginMode)}
            className="text-primary font-bold hover:underline transition-all"
          >
            {isLoginMode ? "ليس لديك حساب؟ أنشئ حساباً جديداً" : "لديك حساب بالفعل؟ سجل دخولك"}
          </button>
        </div>

        <p className="text-center text-xs text-on-surface-variant px-10 leading-relaxed">
          باستخدامك للموقع، أنت توافق على شروط الخدمة وسياسة الخصوصية الخاصة بمتجر الشهابي.
        </p>
      </div>
    </motion.div>
  );
}

function AdminView({ products, setProducts, slides, setSlides, orders, setOrders, formatPrice, isAuthenticated, setIsAuthenticated, showMessage, adminPassword, setAdminPassword, setView }: any) {
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [editingSlide, setEditingSlide] = useState<Partial<HomeSlide> | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"products" | "slides" | "orders" | "settings">("products");
  const [isUploading, setIsUploading] = useState(false);
  const [adminEmails, setAdminEmails] = useState<string[]>(["yahyaalbnaa6@gmail.com"]);

  useEffect(() => {
    if (activeTab === "settings") {
      const fetchAdminEmails = async () => {
        try {
          const docRef = doc(db, "settings", "admin_config");
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setAdminEmails(docSnap.data().adminEmails || ["yahyaalbnaa6@gmail.com"]);
          }
        } catch (err) {
          console.error("Fetch Admin Emails Error:", err);
        }
      };
      fetchAdminEmails();
    }
  }, [activeTab]);
  const [showPasswordLogin, setShowPasswordLogin] = useState(false);

  const handleUpdatePassword = async (e: FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) {
      showMessage("كلمة المرور يجب أن تكون 6 أحرف على الأقل", "error");
      return;
    }
    try {
      await setDoc(doc(db, "settings", "admin_config"), { password: newPassword });
      setAdminPassword(newPassword);
      setNewPassword("");
      showMessage("تم تغيير كلمة المرور بنجاح", "success");
    } catch (error) {
      showMessage("فشل تغيير كلمة المرور", "error");
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'main' | 'additional' | 'slide' | 'certificate', index?: number) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const options = {
        maxSizeMB: 0.1, // Keep it small for Firestore
        maxWidthOrHeight: 800,
        useWebWorker: true
      };
      const compressedFile = await imageCompression(file, options);
      const base64 = await imageCompression.getDataUrlFromFile(compressedFile);

      if (type === 'main' && editingProduct) {
        setEditingProduct({ ...editingProduct, image: base64 });
      } else if (type === 'certificate' && editingProduct) {
        setEditingProduct({ ...editingProduct, certificateImage: base64 });
      } else if (type === 'additional' && editingProduct && index !== undefined) {
        const images = [...(editingProduct.images || [])];
        images[index] = base64;
        setEditingProduct({ ...editingProduct, images });
      } else if (type === 'slide' && editingSlide) {
        setEditingSlide({ ...editingSlide, image: base64 });
      }
      showMessage("تم رفع الصورة بنجاح", "success");
    } catch (error) {
      console.error("Upload Error:", error);
      showMessage("فشل رفع الصورة", "error");
    } finally {
      setIsUploading(false);
    }
  };

  const handleLogin = (e: FormEvent) => {
    e.preventDefault();
    if (password === adminPassword) {
      setIsAuthenticated(true);
      showMessage("تم الدخول برمز الوصول. يرجى تسجيل الدخول عبر جوجل إذا كنت بحاجة لتعديل البيانات.", "info");
    } else {
      showMessage("كلمة المرور خاطئة", "error");
    }
  };

  const toggleProductStatus = async (id: string) => {
    const product = products.find((p: Product) => p.id === id);
    if (!product) return;
    try {
      await updateDoc(doc(db, "products", id), { active: !product.active });
      showMessage("تم تحديث حالة المنتج", "success");
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `products/${id}`);
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      await deleteDoc(doc(db, "products", id));
      setShowDeleteConfirm(null);
      showMessage("تم حذف المنتج", "error");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `products/${id}`);
    }
  };

  const deleteSlide = async (id: string) => {
    try {
      await deleteDoc(doc(db, "slides", id));
      showMessage("تم حذف السلايد", "error");
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `slides/${id}`);
    }
  };

  const handleAddEditProduct = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    
    const productData = {
      ...editingProduct,
      images: editingProduct.images || [],
      sizes: editingProduct.sizes || [],
      active: editingProduct.active ?? true,
      isOffer: editingProduct.isOffer ?? false,
      isDiscounted: editingProduct.isDiscounted ?? false,
    } as Product;

    // Only calculate if the manager hasn't entered a specific price or if they want auto-calculation
    if (productData.isDiscounted && productData.discountPercentage && !productData.price) {
      const originalPrice = productData.oldPrice || 0;
      productData.price = Math.round(originalPrice * (1 - productData.discountPercentage / 100));
      productData.oldPrice = originalPrice;
      productData.badge = `خصم ${productData.discountPercentage}%`;
    }

    try {
      if (editingProduct.id) {
        // Use setDoc with merge: true or just setDoc if we want to overwrite
        await setDoc(doc(db, "products", editingProduct.id), sanitizeForFirestore(productData));
      } else {
        const newDoc = doc(collection(db, "products"));
        const newId = newDoc.id;
        await setDoc(newDoc, sanitizeForFirestore({ ...productData, id: newId }));
      }
      setEditingProduct(null);
      showMessage("تم حفظ المنتج بنجاح", "success");
    } catch (error) {
      console.error("Save Product Error:", error);
      handleFirestoreError(error, OperationType.WRITE, "products");
    }
  };

  const handleAddEditSlide = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingSlide) return;
    
    try {
      if (editingSlide.id) {
        await updateDoc(doc(db, "slides", editingSlide.id), sanitizeForFirestore(editingSlide));
      } else {
        const newDoc = doc(collection(db, "slides"));
        await setDoc(newDoc, sanitizeForFirestore({ ...editingSlide, id: newDoc.id }));
      }
      setEditingSlide(null);
      showMessage("تم حفظ السلايد بنجاح", "success");
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "slides");
    }
  };

  const addSize = () => {
    const sizes = [...(editingProduct?.sizes || []), { label: "", price: 0 }];
    setEditingProduct({ ...editingProduct, sizes });
  };

  const removeSize = (index: number) => {
    const sizes = (editingProduct?.sizes || []).filter((_, i) => i !== index);
    setEditingProduct({ ...editingProduct, sizes });
  };

  const updateSize = (index: number, field: string, value: any) => {
    const sizes = [...(editingProduct?.sizes || [])];
    sizes[index] = { ...sizes[index], [field]: value };
    setEditingProduct({ ...editingProduct, sizes });
  };

  const addImage = () => {
    const images = [...(editingProduct?.images || []), ""];
    setEditingProduct({ ...editingProduct, images });
  };

  const removeImage = (index: number) => {
    const images = (editingProduct?.images || []).filter((_, i) => i !== index);
    setEditingProduct({ ...editingProduct, images });
  };

  const updateImage = (index: number, value: string) => {
    const images = [...(editingProduct?.images || [])];
    images[index] = value;
    setEditingProduct({ ...editingProduct, images });
  };

  const handleGoogleLogin = async () => {
    try {
      const { googleProvider, signInWithPopup } = await import("./firebase");
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      
      if (!user.email) {
        throw new Error("No email found");
      }

      // Check if email is authorized
      const docRef = doc(db, "settings", "admin_config");
      const docSnap = await getDoc(docRef);
      const authorizedEmails = docSnap.exists() ? docSnap.data().adminEmails || ["yahyaalbnaa6@gmail.com"] : ["yahyaalbnaa6@gmail.com"];
      
      if (authorizedEmails.includes(user.email)) {
        setIsAuthenticated(true);
        showMessage("تم تسجيل الدخول بنجاح", "success");
      } else {
        await auth.signOut();
        showMessage("عذراً، هذا الحساب غير مصرح له بالدخول كمدير", "error");
      }
    } catch (error) {
      console.error("Login Error:", error);
      showMessage("فشل تسجيل الدخول", "error");
    }
  };

  if (!isAuthenticated) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="max-w-sm mx-auto py-20 text-center space-y-8">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
          <Settings size={40} className="text-primary" />
        </div>
        <h2 className="text-2xl font-bold">لوحة التحكم</h2>
        
        <div className="space-y-4">
          <p className="text-sm text-on-surface-variant">يرجى تسجيل الدخول للمتابعة</p>
          
          <button 
            onClick={handleGoogleLogin}
            className="w-full py-4 bg-white text-black border border-gray-200 rounded-full font-bold flex items-center justify-center gap-3 shadow-lg hover:bg-gray-50 transition-all active:scale-95"
          >
            <img 
              src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" 
              className="w-6 h-6" 
              alt="Google Logo" 
              referrerPolicy="no-referrer"
            />
            الدخول عبر جوجل (للمسؤول)
          </button>

          {!showPasswordLogin ? (
            <button 
              onClick={() => setShowPasswordLogin(true)}
              className="text-primary text-sm font-bold hover:underline"
            >
              أو الدخول عبر رمز الوصول
            </button>
          ) : (
            <motion.form 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onSubmit={handleLogin} 
              className="space-y-4 pt-4 border-t border-white/10"
            >
              <input 
                type="password" placeholder="رمز الوصول" 
                className="w-full bg-surface-container-low border border-white/5 rounded-2xl p-4 text-center focus:border-primary/50 transition-all outline-none"
                value={password} onChange={e => setPassword(e.target.value)}
              />
              <button type="submit" className="w-full py-4 bg-primary text-on-primary rounded-full font-bold shadow-xl shadow-primary/20 hover:brightness-110 active:scale-95 transition-all">دخول</button>
              <button 
                type="button"
                onClick={() => setShowPasswordLogin(false)}
                className="text-on-surface-variant text-xs"
              >
                إلغاء
              </button>
            </motion.form>
          )}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 pb-10">
      <div className="flex justify-between items-center gap-4">
        <button 
          onClick={() => setView("home")}
          className="p-3 bg-primary/10 text-primary rounded-2xl hover:bg-primary/20 transition-all flex items-center gap-2 font-bold text-sm"
          title="العودة للمتجر"
        >
          <Home size={20} />
          <span className="hidden md:inline">المتجر</span>
        </button>
        <div className="flex gap-2 bg-surface-container-low p-1 rounded-2xl border border-white/5 flex-1 overflow-x-auto hide-scrollbar">
          <button onClick={() => setActiveTab("products")} className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all whitespace-nowrap ${activeTab === "products" ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:bg-white/5"}`}>المنتجات</button>
          <button onClick={() => setActiveTab("slides")} className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all whitespace-nowrap ${activeTab === "slides" ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:bg-white/5"}`}>السلايدر</button>
          <button onClick={() => setActiveTab("orders")} className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all whitespace-nowrap ${activeTab === "orders" ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:bg-white/5"}`}>الطلبات</button>
          <button onClick={() => setActiveTab("settings")} className={`flex-1 py-3 px-4 rounded-xl font-bold transition-all whitespace-nowrap ${activeTab === "settings" ? "bg-primary text-on-primary shadow-lg" : "text-on-surface-variant hover:bg-white/5"}`}>الإعدادات</button>
        </div>
        <button 
          onClick={async () => {
            const { auth } = await import("./firebase");
            await auth.signOut();
            setIsAuthenticated(false);
            showMessage("تم تسجيل الخروج", "info");
          }}
          className="p-3 bg-error/10 text-error rounded-2xl hover:bg-error/20 transition-all"
          title="تسجيل الخروج"
        >
          <X size={24} />
        </button>
      </div>

      {/* Admin Auth Warning */}
      {(!auth.currentUser?.email || !adminEmails.includes(auth.currentUser.email)) && (
        <div className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl flex items-center gap-4 text-amber-500 text-xs font-bold">
          <Lock size={20} />
          <p className="flex-1">أنت مسجل دخول عبر رمز الوصول فقط. بعض العمليات (مثل تحديث الطلبات) قد تتطلب تسجيل الدخول عبر جوجل بحساب المسؤول.</p>
          <button 
            onClick={handleGoogleLogin}
            className="bg-amber-500 text-black px-4 py-2 rounded-xl hover:bg-amber-600 transition-all"
          >
            تسجيل دخول جوجل
          </button>
        </div>
      )}

      {activeTab === "products" ? (
        <>
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة المنتجات</h2>
            <button onClick={() => setEditingProduct({ name: "", price: undefined as any, description: "", category: "العسل السدر", image: "", images: [], sizes: [], isOffer: false, isDiscounted: false })} className="bg-primary text-on-primary p-3 rounded-full shadow-lg shadow-primary/20"><Plus /></button>
          </div>

          <div className="space-y-4">
            {products.map((p: Product) => (
              <div key={p.id} className="bg-surface-container-low p-4 rounded-3xl flex items-center gap-4 border border-white/5 hover:border-primary/20 transition-all">
                <img src={p.image} className="w-16 h-16 rounded-xl object-cover" alt="" />
                <div className="flex-1">
                  <h4 className="font-bold">{p.name}</h4>
                  <p className="text-xs text-on-surface-variant">{p.price} ر.ي / كيلو</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingProduct(p)} className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-all"><Settings size={20} /></button>
                  <button onClick={() => toggleProductStatus(p.id)} className={`p-2 transition-all ${p.active ? "text-green-500" : "text-on-surface/20"}`}><CheckCircle2 size={20} /></button>
                  <button onClick={() => setShowDeleteConfirm(p.id)} className="p-2 text-error hover:bg-error/10 rounded-lg transition-all"><Trash2 size={20} /></button>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : activeTab === "slides" ? (
        <>
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">إدارة السلايدر</h2>
            <button onClick={() => setEditingSlide({ title: "", subtitle: "", image: "", link: "products" })} className="bg-primary text-on-primary p-3 rounded-full shadow-lg shadow-primary/20"><Plus /></button>
          </div>

          <div className="space-y-4">
            {slides.map((s: HomeSlide) => (
              <div key={s.id} className="bg-surface-container-low p-4 rounded-3xl flex items-center gap-4 border border-white/5">
                <img src={s.image} className="w-24 h-16 rounded-xl object-cover" alt="" />
                <div className="flex-1">
                  <h4 className="font-bold">{s.title}</h4>
                  <p className="text-xs text-on-surface-variant">{s.subtitle}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setEditingSlide(s)} className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-all"><Settings size={20} /></button>
                  <button onClick={() => deleteSlide(s.id)} className="p-2 text-error hover:bg-error/10 rounded-lg transition-all"><Trash2 size={20} /></button>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : activeTab === "settings" ? (
        <div className="max-w-md mx-auto space-y-8 py-10">
          <div className="text-center space-y-2">
            <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Settings size={32} />
            </div>
            <h3 className="text-2xl font-bold">إعدادات النظام</h3>
            <p className="text-on-surface-variant text-sm">تخصيص لوحة التحكم والأمان</p>
          </div>

          <div className="space-y-6">
            <form onSubmit={handleUpdatePassword} className="bg-surface-container-low p-8 rounded-[40px] border border-white/5 space-y-6 shadow-xl">
              <h4 className="font-bold flex items-center gap-2"><Lock size={18} className="text-primary" /> رمز الوصول</h4>
              <div className="space-y-2">
                <label className="text-sm font-bold px-2">رمز الوصول الجديد</label>
                <input 
                  type="password" 
                  placeholder="أدخل الرمز الجديد" 
                  className="w-full bg-background border border-white/5 rounded-2xl p-4 outline-none focus:border-primary/50 transition-all"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <button type="submit" className="w-full py-4 bg-primary text-on-primary rounded-full font-bold shadow-lg shadow-primary/20 hover:brightness-110 active:scale-95 transition-all">
                تحديث الرمز
              </button>
            </form>

            <div className="bg-surface-container-low p-8 rounded-[40px] border border-white/5 space-y-6 shadow-xl">
              <h4 className="font-bold flex items-center gap-2"><Mail size={18} className="text-primary" /> مدراء النظام (Google)</h4>
              <div className="space-y-4">
                <p className="text-xs text-on-surface-variant">يمكن لهؤلاء المستخدمين الدخول تلقائياً عبر جوجل</p>
                <div className="space-y-2">
                  {adminEmails.map((email) => (
                    <div key={email} className="p-3 bg-background rounded-xl border border-white/5 text-sm flex justify-between items-center">
                      <span>{email}</span>
                      {email === "yahyaalbnaa6@gmail.com" ? (
                        <span className="text-[10px] bg-primary/20 text-primary px-2 py-0.5 rounded-full">أساسي</span>
                      ) : (
                        <button 
                          onClick={async () => {
                            try {
                              const newEmails = adminEmails.filter(e => e !== email);
                              const docRef = doc(db, "settings", "admin_config");
                              await setDoc(docRef, { adminEmails: newEmails }, { merge: true });
                              setAdminEmails(newEmails);
                              showMessage("تم حذف المدير بنجاح", "success");
                            } catch (err) {
                              showMessage("فشل حذف المدير", "error");
                            }
                          }}
                          className="text-error hover:bg-error/10 p-1 rounded-lg transition-all"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input 
                    type="email" 
                    id="newAdminEmail"
                    placeholder="إضافة إيميل جديد" 
                    className="flex-1 bg-background border border-white/5 rounded-xl p-3 text-sm outline-none focus:border-primary/50"
                  />
                  <button 
                    onClick={async () => {
                      const emailInput = document.getElementById('newAdminEmail') as HTMLInputElement;
                      const email = emailInput.value.trim();
                      if (!email) return;
                      try {
                        const docRef = doc(db, "settings", "admin_config");
                        const docSnap = await getDoc(docRef);
                        const currentEmails = docSnap.exists() ? docSnap.data().adminEmails || ["yahyaalbnaa6@gmail.com"] : ["yahyaalbnaa6@gmail.com"];
                        if (!currentEmails.includes(email)) {
                          const updatedEmails = [...currentEmails, email];
                          await setDoc(docRef, { adminEmails: updatedEmails }, { merge: true });
                          setAdminEmails(updatedEmails);
                          showMessage("تمت إضافة المدير بنجاح", "success");
                          emailInput.value = "";
                        } else {
                          showMessage("الإيميل موجود مسبقاً", "info");
                        }
                      } catch (err) {
                        showMessage("فشل إضافة المدير", "error");
                      }
                    }}
                    className="bg-primary text-on-primary px-4 rounded-xl font-bold"
                  >
                    إضافة
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-primary/5 p-6 rounded-3xl border border-primary/10">
            <h4 className="font-bold text-primary mb-2 flex items-center gap-2">
              <CheckCircle2 size={18} /> ملاحظة أمان
            </h4>
            <p className="text-xs text-on-surface-variant leading-relaxed">
              تغيير رمز الوصول سيؤثر على الدخول اليدوي فقط. الدخول عبر حساب جوجل سيبقى متاحاً دائماً للمدراء المعتمدين.
            </p>
          </div>
        </div>
      ) : (
        <AdminOrdersManager orders={orders} formatPrice={formatPrice} showMessage={showMessage} />
      )}

      {/* Custom Delete Confirmation Modal */}
      <AnimatePresence>
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="bg-surface-container-high p-8 rounded-[40px] max-w-sm w-full text-center space-y-6 border border-white/10">
              <div className="w-20 h-20 bg-error/10 text-error rounded-full flex items-center justify-center mx-auto">
                <Trash2 size={40} />
              </div>
              <h3 className="text-xl font-bold">حذف المنتج؟</h3>
              <p className="text-on-surface-variant text-sm">هل أنت متأكد من حذف هذا المنتج؟ لا يمكن التراجع عن هذا الإجراء.</p>
              <div className="flex gap-3">
                <button onClick={() => setShowDeleteConfirm(null)} className="flex-1 py-3 bg-surface-container-low rounded-full font-bold">إلغاء</button>
                <button onClick={() => deleteProduct(showDeleteConfirm)} className="flex-1 py-3 bg-error text-white rounded-full font-bold">حذف</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {editingProduct && (
        <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center p-6">
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-surface-container-high w-full max-w-2xl p-8 rounded-[40px] border border-white/10 space-y-6 overflow-y-auto max-h-[90vh] hide-scrollbar">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingProduct.id ? "تعديل منتج" : "إضافة منتج جديد"}</h3>
              <button onClick={() => setEditingProduct(null)}><X /></button>
            </div>
            <form onSubmit={handleAddEditProduct} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-4">
                  <input type="text" placeholder="اسم المنتج" required className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingProduct.name} onChange={e => setEditingProduct({...editingProduct, name: e.target.value})} />
                  
                  <div className="bg-background/50 p-4 rounded-2xl border border-white/5 space-y-4">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-sm font-bold">هل هذا المنتج عرض؟</span>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" checked={editingProduct.isOffer} onChange={e => setEditingProduct({...editingProduct, isOffer: e.target.checked})} />
                        <div className="w-11 h-6 bg-surface-container-high peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                      </div>
                    </label>
                    {editingProduct.isOffer && (
                      <div className="grid grid-cols-2 gap-2 animate-in fade-in slide-in-from-top-2">
                        <input type="number" placeholder="السعر القديم" className="w-full bg-background border border-white/5 rounded-xl p-3 text-sm" value={editingProduct.oldPrice || ""} onChange={e => setEditingProduct({...editingProduct, oldPrice: Number(e.target.value)})} />
                        <input type="number" placeholder="السعر الجديد" className="w-full bg-background border border-white/5 rounded-xl p-3 text-sm" value={editingProduct.price || ""} onChange={e => setEditingProduct({...editingProduct, price: Number(e.target.value)})} />
                      </div>
                    )}
                  </div>

                  <div className="bg-background/50 p-4 rounded-2xl border border-white/5 space-y-4">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="text-sm font-bold">تفعيل تخفيض؟</span>
                      <div className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" checked={editingProduct.isDiscounted} onChange={e => setEditingProduct({...editingProduct, isDiscounted: e.target.checked})} />
                        <div className="w-11 h-6 bg-surface-container-high peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                      </div>
                    </label>
                    {editingProduct.isDiscounted && (
                      <div className="grid grid-cols-2 gap-2 animate-in fade-in slide-in-from-top-2">
                        <input type="number" placeholder="السعر الأصلي" className="w-full bg-background border border-white/5 rounded-xl p-3 text-sm" value={editingProduct.oldPrice || editingProduct.price || ""} onChange={e => setEditingProduct({...editingProduct, oldPrice: Number(e.target.value)})} />
                        <input type="number" placeholder="نسبة التخفيض %" className="w-full bg-background border border-white/5 rounded-xl p-3 text-sm" value={editingProduct.discountPercentage || ""} onChange={e => setEditingProduct({...editingProduct, discountPercentage: Number(e.target.value)})} />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-on-surface-variant">نص الشارة (Badge):</label>
                    <input type="text" placeholder="مثلاً: الأكثر مبيعاً، عرض خاص" className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingProduct.badge || ""} onChange={e => setEditingProduct({...editingProduct, badge: e.target.value})} />
                  </div>

                  {!editingProduct.isOffer && !editingProduct.isDiscounted && (
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-on-surface-variant">السعر:</label>
                      <input type="number" placeholder="السعر" required className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingProduct.price === 0 ? "" : (editingProduct.price || "")} onChange={e => setEditingProduct({...editingProduct, price: Number(e.target.value)})} />
                    </div>
                  )}

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-on-surface-variant">التصنيف:</label>
                    <select className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingProduct.category} onChange={e => setEditingProduct({...editingProduct, category: e.target.value})}>
                      <option>العسل VIP</option>
                      <option>العسل السدر</option>
                      <option>العسل السمر</option>
                      <option>خلطات</option>
                      <option>المكسرات</option>
                      <option>الشمع</option>
                    </select>
                    <input 
                      type="text" 
                      placeholder="أو أضف تصنيف جديد..." 
                      className="w-full bg-background border border-white/5 rounded-2xl p-4 text-sm mt-2" 
                      onChange={e => {
                        if (e.target.value.trim() !== "") {
                          setEditingProduct({...editingProduct, category: e.target.value});
                        }
                      }} 
                    />
                  </div>
                  <textarea placeholder="الوصف" required className="w-full bg-background border border-white/5 rounded-2xl p-4 h-32" value={editingProduct.description} onChange={e => setEditingProduct({...editingProduct, description: e.target.value})} />
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-on-surface-variant">الصورة الرئيسية:</label>
                      <div className="flex gap-2">
                        <label className="cursor-pointer text-primary text-[10px] font-bold flex items-center gap-1 bg-primary/10 px-2 py-1 rounded-lg hover:bg-primary/20 transition-all">
                          <Plus size={12} /> رفع مباشر
                          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'main')} disabled={isUploading} />
                        </label>
                        <button 
                          type="button" 
                          onClick={() => window.open("https://postimages.org/", "_blank")}
                          className="text-on-surface-variant text-[10px] font-bold flex items-center gap-1 bg-white/5 px-2 py-1 rounded-lg"
                        >
                          <ExternalLink size={12} /> PostImages
                        </button>
                      </div>
                    </div>
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="رابط الصورة أو سيظهر هنا بعد الرفع" 
                        required 
                        className="w-full bg-background border border-white/5 rounded-2xl p-4 pr-12 text-xs" 
                        value={editingProduct.image} 
                        onChange={e => setEditingProduct({...editingProduct, image: e.target.value})} 
                      />
                      {isUploading ? <div className="absolute left-4 top-1/2 -translate-y-1/2 animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" /> : <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={20} />}
                    </div>
                    <LivePreview url={editingProduct.image || ""} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-on-surface-variant">شهادة الجودة / المنشأ (اختياري):</label>
                      <label className="cursor-pointer text-secondary text-[10px] font-bold flex items-center gap-1 bg-secondary/10 px-2 py-1 rounded-lg hover:bg-secondary/20 transition-all">
                        <Upload size={12} /> رفع الشهادة
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'certificate')} disabled={isUploading} />
                      </label>
                    </div>
                    <div className="relative">
                      <input 
                        type="text" 
                        placeholder="رابط صورة الشهادة" 
                        className="w-full bg-background border border-white/5 rounded-2xl p-4 pr-12 text-xs" 
                        value={editingProduct.certificateImage || ""} 
                        onChange={e => setEditingProduct({...editingProduct, certificateImage: e.target.value})} 
                      />
                      <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-on-surface-variant" size={20} />
                    </div>
                    <LivePreview url={editingProduct.certificateImage || ""} />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-on-surface-variant">صور إضافية (حتى 4):</label>
                      <button type="button" onClick={addImage} className="text-primary text-xs font-bold">+ إضافة حقل</button>
                    </div>
                    <div className="space-y-2">
                      {editingProduct.images?.map((img, idx) => (
                        <div key={idx} className="space-y-2">
                          <div className="flex gap-2">
                            <input type="text" placeholder="رابط الصورة" className="flex-1 bg-background border border-white/5 rounded-xl p-2 text-xs" value={img} onChange={e => updateImage(idx, e.target.value)} />
                            <label className="cursor-pointer p-2 text-primary hover:bg-primary/10 rounded-lg transition-all">
                              <Plus size={16} />
                              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'additional', idx)} disabled={isUploading} />
                            </label>
                            <button type="button" onClick={() => removeImage(idx)} className="text-error"><X size={16} /></button>
                          </div>
                          <LivePreview url={img} />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-on-surface-variant">الأحجام والأسعار:</label>
                      <button type="button" onClick={addSize} className="text-primary text-xs font-bold">+ إضافة حجم</button>
                    </div>
                    <div className="space-y-2">
                      {editingProduct.sizes?.map((size, idx) => (
                        <div key={idx} className="grid grid-cols-3 gap-2">
                          <select className="bg-background border border-white/5 rounded-xl p-2 text-[10px]" value={size.label} onChange={e => updateSize(idx, "label", e.target.value)}>
                            <option value="">اختر الحجم</option>
                            <option value="ربع كيلو">ربع كيلو</option>
                            <option value="نص كيلو">نص كيلو</option>
                            <option value="كيلو">كيلو</option>
                            <option value="قارورة">قارورة</option>
                            <option value="دبة 7 كيلو">دبة 7 كيلو</option>
                          </select>
                          <input type="number" placeholder="السعر" className="bg-background border border-white/5 rounded-xl p-2 text-xs" value={size.price} onChange={e => updateSize(idx, "price", Number(e.target.value))} />
                          <button type="button" onClick={() => removeSize(idx)} className="text-error flex justify-center items-center"><X size={16} /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full py-5 bg-primary text-on-primary rounded-full font-bold text-lg shadow-xl shadow-primary/20">حفظ المنتج</button>
            </form>
          </motion.div>
        </div>
      )}

      {editingSlide && (
        <div className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-xl flex items-center justify-center p-6">
          <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} className="bg-surface-container-high w-full max-w-md p-8 rounded-[40px] border border-white/10 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold">{editingSlide.id ? "تعديل سلايد" : "إضافة سلايد جديد"}</h3>
              <button onClick={() => setEditingSlide(null)}><X /></button>
            </div>
            <form onSubmit={handleAddEditSlide} className="space-y-4">
              <input type="text" placeholder="العنوان الرئيسي" required className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingSlide.title} onChange={e => setEditingSlide({...editingSlide, title: e.target.value})} />
              <input type="text" placeholder="العنوان الفرعي" required className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingSlide.subtitle} onChange={e => setEditingSlide({...editingSlide, subtitle: e.target.value})} />
              
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-on-surface-variant">رابط الصورة:</label>
                  <div className="flex gap-2">
                    <label className="cursor-pointer text-primary text-[10px] font-bold flex items-center gap-1 bg-primary/10 px-2 py-1 rounded-lg hover:bg-primary/20 transition-all">
                      <Plus size={12} /> رفع مباشر
                      <input type="file" accept="image/*" className="hidden" onChange={(e) => handleImageUpload(e, 'slide')} disabled={isUploading} />
                    </label>
                    <button 
                      type="button" 
                      onClick={() => window.open("https://postimages.org/", "_blank")}
                      className="text-on-surface-variant text-[10px] font-bold flex items-center gap-1 bg-white/5 px-2 py-1 rounded-lg"
                    >
                      <ExternalLink size={12} /> PostImages
                    </button>
                  </div>
                </div>
                <div className="relative">
                  <input type="text" placeholder="رابط الصورة" required className="w-full bg-background border border-white/5 rounded-2xl p-4 pr-12" value={editingSlide.image} onChange={e => setEditingSlide({...editingSlide, image: e.target.value})} />
                  {isUploading && <div className="absolute left-4 top-1/2 -translate-y-1/2 animate-spin w-5 h-5 border-2 border-primary border-t-transparent rounded-full" />}
                </div>
                <LivePreview url={editingSlide.image || ""} />
              </div>

              <select className="w-full bg-background border border-white/5 rounded-2xl p-4" value={editingSlide.link} onChange={e => setEditingSlide({...editingSlide, link: e.target.value})}>
                <option value="products">صفحة المنتجات</option>
                <option value="contact">تواصل معنا</option>
              </select>
              <button type="submit" className="w-full py-4 bg-primary text-on-primary rounded-full font-bold shadow-xl shadow-primary/20">حفظ السلايد</button>
            </form>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
}
