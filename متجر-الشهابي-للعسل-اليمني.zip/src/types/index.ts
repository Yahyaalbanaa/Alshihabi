export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number;
  discount?: number;
  category: string;
  image: string;
  images: string[];
  active: boolean;
  isOffer: boolean;
  isDiscounted?: boolean;
  discountPercentage?: number;
  badge?: string;
  sizes?: { label: string; price: number }[];
  certificateImage?: string;
}

export interface HomeSlide {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  link: string;
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize?: string;
  finalPrice: number;
}

export interface OrderDetails {
  name: string;
  phone: string;
  country: string;
  governorate?: string;
  city: string;
  address: string;
  notes: string;
  paymentMethod: string;
  locationUrl?: string;
}

export interface Order {
  id: string;
  date: string;
  details: OrderDetails;
  items: CartItem[];
  total: number;
  status: "received" | "processing" | "shipped" | "delivered" | "rejected";
  currency: CurrencyOption;
}

export type CurrencyCode = "OLD_YER" | "NEW_YER" | "SAR" | "USD";

export interface CurrencyOption {
  code: CurrencyCode;
  label: string;
  symbol: string;
  rate: number; // Rate to convert from OLD_YER to this currency
}
