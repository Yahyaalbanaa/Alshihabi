import React from "react";
import { motion } from "motion/react";
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin, ArrowUp } from "lucide-react";
import { WhatsAppIcon } from "./WhatsAppIcon";
import { Logo } from "./Assets";

export function Footer({ setView }: { setView: (v: any) => void }) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-surface-container-low mt-32 pt-20 pb-10 border-t border-amber-900/5 dark:border-white/5 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Section */}
          <div className="space-y-6 text-right">
            <div onClick={() => { setView("home"); scrollToTop(); }} className="flex items-center gap-3 cursor-pointer group">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center p-2 border border-primary/20">
                <Logo />
              </div>
              <h2 className="font-headline font-bold text-2xl">الشهابي</h2>
            </div>
            <p className="text-on-surface-variant text-sm leading-relaxed">
              نحن نفخر بتقديم أجود أنواع العسل اليمني الحضرمي الأصيل، نجمع بين عراقة الماضي وجودة الحاضر لنقدم لكم شفاءً وغذاءً طبيعياً 100%.
            </p>
            <div className="flex items-center gap-4 justify-end">
              {[
                { icon: <Instagram size={18} />, link: "https://instagram.com" },
                { icon: <Facebook size={18} />, link: "https://facebook.com" },
                { icon: <Twitter size={18} />, link: "https://twitter.com" },
                { icon: <WhatsAppIcon size={18} />, link: "https://wa.me/967774586524" }
              ].map((social, i) => (
                <motion.a
                  key={i}
                  href={social.link}
                  whileHover={{ y: -3, scale: 1.1 }}
                  className="w-10 h-10 rounded-xl bg-surface-container-high flex items-center justify-center text-on-surface-variant hover:text-primary transition-colors border border-white/5 shadow-sm"
                >
                  {social.icon}
                </motion.a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6 text-right">
            <h4 className="font-bold text-lg">روابط سريعة</h4>
            <ul className="space-y-3">
              {[
                { label: "الرئيسية", view: "home" },
                { label: "منتجاتنا", view: "products" },
                { label: "المفضلة", view: "favorites" },
                { label: "تواصل معنا", view: "contact" }
              ].map((link, i) => (
                <li key={i}>
                  <button 
                    onClick={() => { setView(link.view as any); scrollToTop(); }}
                    className="text-on-surface-variant hover:text-primary transition-colors text-sm"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div className="space-y-6 text-right">
            <h4 className="font-bold text-lg">أصناف العسل</h4>
            <ul className="space-y-3">
              {["عسل سدر ملكي", "عسل سمر أصيل", "عسل صال حضرمي", "خلطات الطاقة"].map((cat, i) => (
                <li key={i}>
                  <button 
                    onClick={() => { setView("products"); scrollToTop(); }}
                    className="text-on-surface-variant hover:text-primary transition-colors text-sm"
                  >
                    {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-6 text-right">
            <h4 className="font-bold text-lg">معلومات التواصل</h4>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 justify-end text-sm text-on-surface-variant">
                <span>حضرموت، اليمن</span>
                <MapPin size={16} className="text-primary" />
              </li>
              <li className="flex items-center gap-3 justify-end text-sm text-on-surface-variant">
                <span>967774586524+</span>
                <Phone size={16} className="text-primary" />
              </li>
              <li className="flex items-center gap-3 justify-end text-sm text-on-surface-variant">
                <span>info@alshehabi.com</span>
                <Mail size={16} className="text-primary" />
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-xs text-on-surface-variant opacity-60">
            © {new Date().getFullYear()} الشهابي للعسل الحضرمي. جميع الحقوق محفوظة.
          </p>
          
          <button 
            onClick={scrollToTop}
            className="flex items-center gap-2 text-xs font-bold text-primary hover:opacity-80 transition-opacity"
          >
            العودة للأعلى
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <ArrowUp size={14} />
            </div>
          </button>
        </div>
      </div>
    </footer>
  );
}
