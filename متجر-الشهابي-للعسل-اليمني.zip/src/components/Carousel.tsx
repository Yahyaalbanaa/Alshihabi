import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Product } from "../types";
import { ShoppingBag, Plus } from "lucide-react";

export function Carousel({ items, onSelect, addToCart, setFullScreenImage, currency, formatPrice }: { items: Product[], onSelect: (p: Product) => void, addToCart?: (p: Product) => void, setFullScreenImage?: (img: string) => void, currency: any, formatPrice: any }) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (items.length === 0) return;
    if (currentIndex >= items.length) setCurrentIndex(0);
    
    const timer = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % items.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [items.length, currentIndex]);

  const paginate = (newDirection: number) => {
    setCurrentIndex(prev => (prev + newDirection + items.length) % items.length);
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const currentItem = items[currentIndex] || items[0];

  if (!currentItem) return null;

  return (
    <div className="relative w-full h-[240px] md:h-[300px] rounded-[24px] overflow-hidden group border border-white/10 shadow-xl">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.8 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);

            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          className="absolute inset-0 cursor-grab active:cursor-grabbing"
        >
          <img 
            src={currentItem.image} 
            alt={currentItem.name}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
            loading="lazy"
            onClick={(e) => {
              if (setFullScreenImage) {
                e.stopPropagation();
                setFullScreenImage(currentItem.image);
              }
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent flex flex-col justify-end p-8 text-white pointer-events-none">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="pointer-events-auto"
            >
              <span className="bg-primary text-on-primary px-2.5 py-0.5 rounded-full text-[8px] font-bold mb-1.5 inline-block uppercase tracking-wider">عرض حصري</span>
              <h2 className="text-lg md:text-xl font-headline font-bold mb-1.5">{currentItem.name}</h2>
              <div className="flex items-center gap-2.5">
                <button 
                  onClick={() => onSelect(currentItem)}
                  className="bg-white text-black px-4 py-1 rounded-full font-bold text-[10px] hover:bg-primary hover:text-white transition-colors"
                >
                  تفاصيل العرض
                </button>
                {addToCart && (
                  <button 
                    onClick={() => addToCart(currentItem)}
                    className="bg-primary text-on-primary w-8 h-8 rounded-full flex items-center justify-center shadow-lg shadow-primary/30 hover:scale-110 active:scale-95 transition-all"
                  >
                    <Plus size={16} />
                  </button>
                )}
                <div className="text-base font-bold text-primary">
                  {formatPrice(currentItem.price)} <span className="text-[9px]">{currency.symbol}</span>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
