import React from "react";

export function Badge({ label, variant = "primary" }: { label: string, variant?: "primary" | "error" | "success" | "warning" | "danger" }) {
  const colors = {
    primary: "bg-primary/20 text-primary border-primary/30",
    error: "bg-error/20 text-error border-error/30",
    success: "bg-green-500/20 text-green-500 border-green-500/30",
    warning: "bg-amber-500/20 text-amber-500 border-amber-500/30",
    danger: "bg-red-500/20 text-red-500 border-red-500/30"
  };

  return (
    <span className={`px-4 py-1 rounded-full text-[10px] font-bold border backdrop-blur-md shadow-lg ${colors[variant]}`}>
      {label}
    </span>
  );
}
