import React from "react";
import { motion } from "motion/react";
import { MapPin, Navigation, ExternalLink, Clock, Phone } from "lucide-react";

export function MapSection() {
  const mapUrl = "https://www.google.com/maps/search/?api=1&query=حضرموت+اليمن"; 
  const mapPreviewImage = "https://images.unsplash.com/photo-1548345680-f5475ee50030?q=80&w=2000&auto=format&fit=crop"; 

  return (
    <section className="mt-32 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
          <div className="lg:col-span-1 space-y-8 text-right">
            <div>
              <h3 className="text-4xl font-headline font-bold mb-4">تفضلوا بزيارتنا</h3>
              <p className="text-on-surface-variant leading-relaxed">نحن نؤمن بأن تجربة العسل تبدأ من الحواس، لذا ندعوكم لزيارة معرضنا الرئيسي لتذوق أجود أنواع العسل الحضرمي الأصيل.</p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4 justify-end">
                <div className="text-right">
                  <h5 className="font-bold text-primary">العنوان</h5>
                  <p className="text-sm text-on-surface-variant">حضرموت، اليمن - الشارع الرئيسي</p>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shrink-0">
                  <MapPin size={20} />
                </div>
              </div>

              <div className="flex items-start gap-4 justify-end">
                <div className="text-right">
                  <h5 className="font-bold text-primary">ساعات العمل</h5>
                  <p className="text-sm text-on-surface-variant">السبت - الخميس: 9:00 ص - 10:00 م</p>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shrink-0">
                  <Clock size={20} />
                </div>
              </div>

              <div className="flex items-start gap-4 justify-end">
                <div className="text-right">
                  <h5 className="font-bold text-primary">للتواصل المباشر</h5>
                  <p className="text-sm text-on-surface-variant">967774586524+</p>
                </div>
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shrink-0">
                  <Phone size={20} />
                </div>
              </div>
            </div>

            <motion.a
              href={mapUrl}
              target="_blank"
              rel="noreferrer"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="inline-flex items-center gap-3 px-8 py-4 bg-primary text-on-primary rounded-2xl font-bold shadow-lg shadow-primary/30 transition-all"
            >
              <Navigation size={20} />
              الحصول على الاتجاهات
            </motion.a>
          </div>

          <motion.a
            href={mapUrl}
            target="_blank"
            rel="noreferrer"
            whileHover={{ y: -8 }}
            className="lg:col-span-2 relative block aspect-video lg:aspect-auto lg:h-[500px] rounded-[48px] overflow-hidden group border border-amber-900/10 dark:border-white/5 shadow-2xl shadow-primary/5"
          >
            <img 
              src={mapPreviewImage} 
              alt="Map Location" 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105 grayscale-[0.2] group-hover:grayscale-0"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-40 group-hover:opacity-60 transition-opacity duration-500" />
            
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500">
              <div className="bg-white/20 backdrop-blur-xl p-6 rounded-3xl border border-white/30 flex items-center gap-4 text-white font-bold">
                <ExternalLink size={24} />
                <span>فتح في خرائط جوجل</span>
              </div>
            </div>

            <div className="absolute bottom-8 right-8 left-8 flex justify-between items-center">
              <div className="bg-white/10 backdrop-blur-md border border-white/20 px-6 py-3 rounded-2xl text-white text-sm font-bold">
                موقعنا في حضرموت
              </div>
            </div>
          </motion.a>
        </div>
      </div>
    </section>
  );
}
