import React from "react";

interface SidebarItemProps {
  icon: any;
  label: string;
  onClick: () => void;
  active: boolean;
}

export function SidebarItem({ icon, label, onClick, active }: SidebarItemProps) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 group ${active ? "bg-primary text-on-primary shadow-xl shadow-primary/30 scale-105" : "bg-white/5 text-on-surface-variant hover:bg-white/10 hover:text-primary border border-white/10"}`}
    >
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${active ? "bg-white/20" : "bg-background group-hover:scale-110"}`}>
        {icon}
      </div>
      <span className="font-bold text-lg">{label}</span>
      {active && <div className="mr-auto w-2 h-2 bg-white rounded-full shadow-[0_0_10px_white]" />}
    </button>
  );
}
