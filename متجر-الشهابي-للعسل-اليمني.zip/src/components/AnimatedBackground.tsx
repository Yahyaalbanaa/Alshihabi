import React from "react";
import { motion } from "motion/react";
import assets from "../data/assets.json";

export function AnimatedBackground() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
      {/* Honeycomb Pattern */}
      <div className="absolute inset-0 opacity-[0.03] dark:opacity-[0.05] transition-opacity duration-1000"
        style={{
          backgroundImage: `url("${assets.honeycombPattern}")`,
          backgroundSize: '52px 60px'
        }}
      />

      {/* Floating Particles (Bees-like) */}
      {[...Array(10)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            x: Math.random() * 100 + "%", 
            y: Math.random() * 100 + "%",
            opacity: 0 
          }}
          animate={{ 
            x: [
              Math.random() * 100 + "%", 
              Math.random() * 100 + "%"
            ],
            y: [
              Math.random() * 100 + "%", 
              Math.random() * 100 + "%"
            ],
            opacity: [0.05, 0.15, 0.05],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 40 + Math.random() * 40, 
            repeat: Infinity, 
            ease: "easeInOut" 
          }}
          className="absolute w-1 h-1 bg-primary rounded-full blur-[2px]"
        />
      ))}

      {/* Subtle Gradients */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/5 via-transparent to-primary/5 dark:from-primary/10 dark:to-transparent" />
    </div>
  );
}
