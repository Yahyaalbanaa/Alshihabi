import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, Sun, Moon } from "lucide-react";
import { Logo } from "./Assets";

interface HeaderProps {
  showHeader: boolean;
  setIsSidebarOpen: (v: boolean) => void;
  setView: (v: any) => void;
  toggleTheme: () => void;
  isDarkMode: boolean;
}

export function Header({ showHeader, setIsSidebarOpen, setView, toggleTheme, isDarkMode }: HeaderProps) {
  return (
    <motion.header 
      initial={{ y: 0 }}
      animate={{ y: showHeader ? 0 : -100 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className="fixed top-0 w-full z-50 bg-background/60 backdrop-blur-3xl flex justify-between items-center px-6 h-20 shadow-sm border-b border-amber-900/5 dark:border-white/5"
    >
      <button 
        onClick={() => setIsSidebarOpen(true)} 
        className="text-primary hover:bg-primary/10 transition-all active:scale-95 duration-200 p-3 rounded-2xl border border-primary/10"
      >
        <Menu size={24} />
      </button>
      
      <div onClick={() => setView("home")} className="flex items-center gap-3 cursor-pointer group">
        <div className="w-14 h-14 bg-primary/5 rounded-2xl flex items-center justify-center shadow-2xl shadow-primary/5 group-hover:scale-110 transition-all duration-500 overflow-hidden border border-primary/10 p-2">
          <Logo />
        </div>
        <div className="hidden md:block text-right">
          <h1 className="font-headline font-bold text-2xl tracking-tight text-on-surface">الشهابي</h1>
          <p className="text-[10px] text-primary font-bold tracking-widest uppercase opacity-80">للعسل الحضرمي</p>
        </div>
      </div>

      <button 
        onClick={toggleTheme} 
        className="relative w-12 h-12 flex items-center justify-center text-primary bg-primary/10 hover:bg-primary/20 rounded-2xl transition-all active:scale-90 duration-200 overflow-hidden border border-primary/20"
      >
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={isDarkMode ? "dark" : "light"}
            initial={{ y: 20, opacity: 0, rotate: -45 }}
            animate={{ y: 0, opacity: 1, rotate: 0 }}
            exit={{ y: -20, opacity: 0, rotate: 45 }}
            transition={{ duration: 0.3, ease: "backOut" }}
          >
            {isDarkMode ? <Sun size={22} /> : <Moon size={22} />}
          </motion.div>
        </AnimatePresence>
      </button>
    </motion.header>
  );
}
