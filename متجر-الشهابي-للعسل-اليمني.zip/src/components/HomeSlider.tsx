import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { HomeSlide } from "../types";

export function HomeSlider({ slides, setView, setFullScreenImage }: { slides: HomeSlide[], setView: (v: any) => void, setFullScreenImage: (img: string) => void }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    if (slides.length <= 1) return;
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex(prev => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const paginate = (newDirection: number) => {
    setDirection(newDirection);
    setCurrentIndex(prev => (prev + newDirection + slides.length) % slides.length);
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  const variants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 1.1
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.9
    })
  };

  const currentSlide = slides[currentIndex] || slides[0];

  if (!currentSlide) return null;

  return (
    <div className="relative h-[300px] sm:h-[400px] w-full overflow-hidden rounded-[32px] shadow-2xl group">
      <AnimatePresence initial={false} custom={direction} mode="wait">
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.5 },
            scale: { duration: 0.8 }
          }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={1}
          onDragEnd={(e, { offset, velocity }) => {
            const swipe = swipePower(offset.x, velocity.x);

            if (swipe < -swipeConfidenceThreshold) {
              paginate(1);
            } else if (swipe > swipeConfidenceThreshold) {
              paginate(-1);
            }
          }}
          className="absolute inset-0 cursor-grab active:cursor-grabbing"
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent z-10" />
          <img 
            src={currentSlide.image} 
            alt={currentSlide.title}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
            loading="lazy"
            onClick={() => setFullScreenImage(currentSlide.image)}
          />
          <div className="absolute inset-0 z-20 flex flex-col justify-end p-6 sm:p-12 text-right pointer-events-none">
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="pointer-events-auto"
            >
              <span className="inline-block px-2.5 py-0.5 bg-primary/20 backdrop-blur-md text-primary rounded-full text-[9px] font-bold mb-2 border border-primary/30">
                مجموعة الشهابي الفاخرة
              </span>
              <h2 className="text-2xl sm:text-4xl font-headline font-bold text-white mb-2 leading-tight drop-shadow-2xl">
                {currentSlide.title}
              </h2>
              <p className="text-white/80 text-sm sm:text-base max-w-xl ml-auto mb-5 font-medium">
                {currentSlide.subtitle}
              </p>
              <div className="flex gap-3 justify-end">
                <button 
                  onClick={() => setView(currentSlide.link)}
                  className="bg-primary hover:bg-primary-container text-on-primary px-6 py-2 rounded-full font-bold text-sm shadow-2xl shadow-primary/40 transition-all hover:scale-105 active:scale-95"
                >
                  تسوق الآن
                </button>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex gap-3 z-30">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => {
              setDirection(i > currentIndex ? 1 : -1);
              setCurrentIndex(i);
            }}
            className={`h-2 rounded-full transition-all duration-500 ${i === currentIndex ? "w-10 bg-primary" : "w-2 bg-white/30 hover:bg-white/50"}`}
          />
        ))}
      </div>

      <button onClick={() => paginate(-1)} className="absolute left-4 top-1/2 -translate-y-1/2 z-30 w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all hover:bg-primary hover:border-primary">
        <ChevronLeft size={20} />
      </button>
      <button onClick={() => paginate(1)} className="absolute right-4 top-1/2 -translate-y-1/2 z-30 w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all hover:bg-primary hover:border-primary">
        <ChevronRight size={20} />
      </button>
    </div>
  );
}
