import React from "react";

export const Logo = () => (
  <img 
    src="https://i.postimg.cc/zX9khYBL/file-1775314248428.png" 
    alt="الشهابي للعسل الحضرمي" 
    className="w-full h-full object-contain"
    referrerPolicy="no-referrer"
  />
);

export const DeveloperAvatar = () => (
  <img 
    src="https://i.postimg.cc/wx2PDM8F/IMG-20260118-135610-179.webp" 
    alt="يحيى خالد البناء" 
    className="w-full h-full object-cover"
    referrerPolicy="no-referrer"
  />
);

export const OwnerAvatar = () => (
  <img 
    src="https://api.dicebear.com/7.x/avataaars/svg?seed=Mohammed&backgroundColor=ffdf00" 
    alt="محمد الشهابي" 
    className="w-full h-full object-cover"
    referrerPolicy="no-referrer"
  />
);
