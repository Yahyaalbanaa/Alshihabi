import React from "react";

export function NavItem({ icon, label, active, onClick }: { icon: any, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center justify-center transition-all duration-300 ${active ? "text-primary bg-surface-container-high rounded-full px-4 py-2" : "text-on-surface/60 hover:scale-110"}`}
    >
      {icon}
      <span className="font-headline font-semibold text-[10px] mt-1">{label}</span>
    </button>
  );
}
