import React from "react";
import { motion } from "motion/react";
import { Heart, ShoppingBag, Star, Plus } from "lucide-react";
import { Product } from "../types";

interface ProductCardProps {
  product: Product;
  addToCart: (p: Product, q?: number, s?: any) => void;
  toggleFavorite: (id: string) => void;
  isFavorite: boolean;
  setView: (v: any) => void;
  setSelectedProduct: (p: Product) => void;
}

export function ProductCard({ product, addToCart, toggleFavorite, isFavorite, setView, setSelectedProduct, setFullScreenImage, currency, formatPrice }: any) {
  const handleCardClick = () => {
    setSelectedProduct(product);
    setView("product-detail");
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -10 }}
      className="group bg-surface rounded-[24px] p-2 transition-all duration-500 luxury-shadow border border-primary/5 cursor-pointer relative"
      onClick={handleCardClick}
    >
      <div className="relative aspect-[4/5] rounded-[20px] overflow-hidden mb-3 bg-surface-container-low">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
          referrerPolicy="no-referrer"
          loading="lazy"
          onClick={(e) => {
            if (setFullScreenImage) {
              e.stopPropagation();
              setFullScreenImage(product.image);
            }
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {product.badge && (
          <div className="absolute top-4 right-4 z-10">
            <span className="glass text-white text-[10px] font-black px-4 py-1.5 rounded-full shadow-xl uppercase tracking-widest">
              {product.badge}
            </span>
          </div>
        )}

        <button 
          onClick={(e) => { e.stopPropagation(); toggleFavorite(product.id); }}
          className={`absolute top-2 left-2 z-10 w-8 h-8 rounded-lg flex items-center justify-center glass transition-all duration-300 ${isFavorite ? "bg-red-500/80 border-red-400 text-white shadow-lg shadow-red-500/30" : "text-white hover:bg-white/20"}`}
        >
          <Heart size={14} fill={isFavorite ? "currentColor" : "none"} />
        </button>
      </div>

      <div className="px-1.5 pb-1.5 space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-[9px] font-black text-primary/60 uppercase tracking-[0.2em]">
            {product.category}
          </span>
          <div className="flex items-center gap-1">
            <Star size={10} className="fill-primary text-primary" />
            <span className="text-[10px] font-bold opacity-60">4.9</span>
          </div>
        </div>
        
        <h3 className="font-headline font-bold text-base md:text-lg line-clamp-1 group-hover:text-primary transition-colors">
          {product.name}
        </h3>
        
        <div className="flex items-center justify-between gap-3 pt-0.5">
          <div className="flex flex-col">
            {product.oldPrice && (
              <span className="text-[9px] text-on-surface-variant line-through opacity-40 mb-0.5">{formatPrice(product.oldPrice)} {currency.symbol}</span>
            )}
            <span className="text-lg font-headline font-black text-primary">{formatPrice(product.price)} {currency.symbol}</span>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); addToCart(product); }}
            className="w-9 h-9 bg-primary text-on-primary rounded-lg flex items-center justify-center shadow-xl shadow-primary/20 hover:scale-110 active:scale-95 transition-all group/btn"
          >
            <Plus size={18} className="group-hover/btn:rotate-90 transition-transform duration-300" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
