import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Phone, ArrowLeft, ExternalLink, Store } from "lucide-react";
import { WhatsAppIcon } from "./WhatsAppIcon";
import { OwnerAvatar } from "./Assets";

export function StoreOwnerCard({ isContactPage = false }: { isContactPage?: boolean }) {
  const [showModal, setShowModal] = useState(false);

  const cardContent = (
    <motion.div 
      onClick={() => setShowModal(true)}
      className={`group flex items-center gap-4 ${isContactPage ? "bg-surface-container-low p-6 rounded-[30px] border border-amber-900/10 dark:border-white/5 hover:bg-surface-container-high" : "p-4 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10"} transition-all cursor-pointer`}
    >
      <div className={`${isContactPage ? "w-14 h-14" : "w-16 h-16"} rounded-2xl bg-primary/10 flex items-center justify-center overflow-hidden border border-primary/20 shadow-inner`}>
        <OwnerAvatar />
      </div>
      <div className={isContactPage ? "text-right flex-1" : "flex-1"}>
        <h4 className="font-bold text-primary group-hover:translate-x-1 transition-transform">محمد الشهابي</h4>
        <p className="text-xs text-on-surface-variant">مالك المتجر والمدير العام</p>
      </div>
      {isContactPage ? (
        <ArrowLeft className="mr-auto text-on-surface/20 group-hover:text-primary transition-colors" size={20} />
      ) : (
        <ExternalLink size={20} className="text-on-surface-variant group-hover:text-primary transition-colors" />
      )}
    </motion.div>
  );

  return (
    <>
      {cardContent}

      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowModal(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-xl"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-surface-container-high/40 backdrop-blur-2xl max-w-md w-full p-8 rounded-[40px] border border-white/20 text-center space-y-6 relative overflow-hidden shadow-[0_32px_64px_-12px_rgba(0,0,0,0.5)]"
            >
              <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-primary/50 via-primary to-primary/50" />
              <button onClick={() => setShowModal(false)} className="absolute top-6 right-6 text-on-surface-variant hover:text-on-surface transition-colors"><X /></button>
              
              <div className="w-24 h-24 rounded-3xl bg-primary/10 mx-auto overflow-hidden border-2 border-primary/20 shadow-2xl">
                <OwnerAvatar />
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-bold">محمد الشهابي</h3>
                <p className="text-primary font-medium">Store Owner & Manager</p>
              </div>

              <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-4 text-sm leading-relaxed text-on-surface/80">
                <p>مرحباً بكم في متجر <span className="text-primary font-bold">الشهابي للعسل الحضرمي</span>. نحن نلتزم بتقديم أجود أنواع العسل الطبيعي والمضمون 100%.</p>
                <div className="h-px bg-white/10" />
                <p className="text-xs text-on-surface-variant/70">خبرة تمتد لأكثر من 50 عاماً في تربية النحل وإنتاج العسل الفاخر من جبال ووديان حضرموت.</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <a href="https://wa.me/967774586524?text=مرحباً أستاذ محمد، أريد الاستفسار عن منتجات العسل" target="_blank" rel="noreferrer" className="flex items-center justify-center gap-2 py-4 bg-[#25D366]/90 hover:bg-[#25D366] text-white rounded-2xl font-bold text-sm shadow-lg shadow-green-500/20 transition-all hover:scale-105 active:scale-95">
                  <WhatsAppIcon size={18} /> واتساب
                </a>
                <a href="tel:+967774586524" className="flex items-center justify-center gap-2 py-4 bg-primary/90 hover:bg-primary text-on-primary rounded-2xl font-bold text-sm shadow-lg shadow-primary/20 transition-all hover:scale-105 active:scale-95">
                  <Phone size={18} /> اتصل بي
                </a>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
